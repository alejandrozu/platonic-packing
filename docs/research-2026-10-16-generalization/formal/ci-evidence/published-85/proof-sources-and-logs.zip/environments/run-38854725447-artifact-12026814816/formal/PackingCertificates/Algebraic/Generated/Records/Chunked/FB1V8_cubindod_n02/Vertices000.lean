import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubindod_n02.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubindod_n02.Vertices000_0000

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubindod_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_piece_0 (p : Fin 8) :
    (certificate.placedCheck 0 p && certificate.vertexContainmentCheck 0 p) = true := by
  exact rangeCheck_sound vertices_0_range_0 p (by omega) (by omega)

#print axioms vertices_piece_0
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubindod_n02
