import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoindod_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoindod_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (icosahedron.normalizationCheck && (icosahedron.verticesCheck && (dodecahedron.normalizationCheck && (dodecahedron.verticesCheck && dodecahedron.centroidCheck 2)))) = true
  simp only [icosahedron_normalization_checked, icosahedron_vertices_checked, dodecahedron_normalization_checked, dodecahedron_vertices_checked, dodecahedron_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoindod_n02_pingyou_20261013
