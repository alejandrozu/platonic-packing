import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_1_range_1 : rangeCheck 8 2 (by decide)
    (fun p => certificate.placedCheck 1 p && certificate.vertexContainmentCheck 1 p) = true := by decide +kernel

#print axioms vertices_1_range_1
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
