import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_0_range_0 : rangeCheck 0 8 (by decide)
    (fun p => certificate.placedCheck 0 p && certificate.vertexContainmentCheck 0 p) = true := by decide +kernel

#print axioms vertices_0_range_0
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013
