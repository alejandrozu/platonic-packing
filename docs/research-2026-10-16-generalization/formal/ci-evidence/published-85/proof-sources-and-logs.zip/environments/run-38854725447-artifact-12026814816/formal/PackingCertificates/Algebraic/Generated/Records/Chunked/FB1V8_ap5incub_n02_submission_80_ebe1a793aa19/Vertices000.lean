import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19.Vertices000_0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19.Vertices000_0001

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_piece_0 (p : Fin 10) :
    (certificate.placedCheck 0 p && certificate.vertexContainmentCheck 0 p) = true := by
  by_cases h8 : p.val < 8
  · exact rangeCheck_sound vertices_0_range_0 p (by omega) (by omega)
  · exact rangeCheck_sound vertices_0_range_1 p (by omega) (by omega)

#print axioms vertices_piece_0
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
