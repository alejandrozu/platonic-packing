import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (prism6.normalizationCheck && (prism6.verticesCheck && (cube.normalizationCheck && (cube.verticesCheck && cube.centroidCheck 1)))) = true
  simp only [prism6_normalization_checked, prism6_vertices_checked, cube_normalization_checked, cube_vertices_checked, cube_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr6incub_n02_pingyou_20261013
