import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (prism5.normalizationCheck && (prism5.verticesCheck && (prism5.normalizationCheck && (prism5.verticesCheck && prism5.centroidCheck 4)))) = true
  simp only [prism5_normalization_checked, prism5_vertices_checked, prism5_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
