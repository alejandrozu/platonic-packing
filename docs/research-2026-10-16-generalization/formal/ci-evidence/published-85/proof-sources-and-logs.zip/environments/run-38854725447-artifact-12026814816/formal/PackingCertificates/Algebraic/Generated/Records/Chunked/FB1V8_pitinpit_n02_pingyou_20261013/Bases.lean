import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0002
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0003
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0004
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0005
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0006
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0007
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0008
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0009
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0010
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0011
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0012
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0013
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0014
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0015
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0016
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0017
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0018
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0019
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0020
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0021
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0022
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0023
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0024
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0025
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0026
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0027
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0028
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0029
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0030
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0031
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013.Basis0032

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem bases_checked : certificate.basisCheck = true := by
  apply basisCheck_of_items
  intro z
  by_cases h16 : z.val < 16
  · by_cases h8 : z.val < 8
    · by_cases h4 : z.val < 4
      · by_cases h2 : z.val < 2
        · by_cases h1 : z.val < 1
          · exact rangeCheck_sound bases_range_0 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_1 z (by omega) (by omega)
        · by_cases h3 : z.val < 3
          · exact rangeCheck_sound bases_range_2 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_3 z (by omega) (by omega)
      · by_cases h6 : z.val < 6
        · by_cases h5 : z.val < 5
          · exact rangeCheck_sound bases_range_4 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_5 z (by omega) (by omega)
        · by_cases h7 : z.val < 7
          · exact rangeCheck_sound bases_range_6 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_7 z (by omega) (by omega)
    · by_cases h12 : z.val < 12
      · by_cases h10 : z.val < 10
        · by_cases h9 : z.val < 9
          · exact rangeCheck_sound bases_range_8 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_9 z (by omega) (by omega)
        · by_cases h11 : z.val < 11
          · exact rangeCheck_sound bases_range_10 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_11 z (by omega) (by omega)
      · by_cases h14 : z.val < 14
        · by_cases h13 : z.val < 13
          · exact rangeCheck_sound bases_range_12 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_13 z (by omega) (by omega)
        · by_cases h15 : z.val < 15
          · exact rangeCheck_sound bases_range_14 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_15 z (by omega) (by omega)
  · by_cases h24 : z.val < 24
    · by_cases h20 : z.val < 20
      · by_cases h18 : z.val < 18
        · by_cases h17 : z.val < 17
          · exact rangeCheck_sound bases_range_16 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_17 z (by omega) (by omega)
        · by_cases h19 : z.val < 19
          · exact rangeCheck_sound bases_range_18 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_19 z (by omega) (by omega)
      · by_cases h22 : z.val < 22
        · by_cases h21 : z.val < 21
          · exact rangeCheck_sound bases_range_20 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_21 z (by omega) (by omega)
        · by_cases h23 : z.val < 23
          · exact rangeCheck_sound bases_range_22 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_23 z (by omega) (by omega)
    · by_cases h28 : z.val < 28
      · by_cases h26 : z.val < 26
        · by_cases h25 : z.val < 25
          · exact rangeCheck_sound bases_range_24 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_25 z (by omega) (by omega)
        · by_cases h27 : z.val < 27
          · exact rangeCheck_sound bases_range_26 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_27 z (by omega) (by omega)
      · by_cases h30 : z.val < 30
        · by_cases h29 : z.val < 29
          · exact rangeCheck_sound bases_range_28 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_29 z (by omega) (by omega)
        · by_cases h31 : z.val < 31
          · exact rangeCheck_sound bases_range_30 z (by omega) (by omega)
          · by_cases h32 : z.val < 32
            · exact rangeCheck_sound bases_range_31 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_32 z (by omega) (by omega)

#print axioms bases_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pitinpit_n02_pingyou_20261013
