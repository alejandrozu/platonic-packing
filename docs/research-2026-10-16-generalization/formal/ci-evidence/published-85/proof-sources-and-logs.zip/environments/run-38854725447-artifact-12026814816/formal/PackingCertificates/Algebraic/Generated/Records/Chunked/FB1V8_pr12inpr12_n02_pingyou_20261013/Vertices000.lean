import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013.Vertices000_0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013.Vertices000_0001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013.Vertices000_0002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_piece_0 (p : Fin 24) :
    (certificate.placedCheck 0 p && certificate.vertexContainmentCheck 0 p) = true := by
  by_cases h8 : p.val < 8
  · exact rangeCheck_sound vertices_0_range_0 p (by omega) (by omega)
  · by_cases h16 : p.val < 16
    · exact rangeCheck_sound vertices_0_range_1 p (by omega) (by omega)
    · exact rangeCheck_sound vertices_0_range_2 p (by omega) (by omega)

#print axioms vertices_piece_0
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr12inpr12_n02_pingyou_20261013
