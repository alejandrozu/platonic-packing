import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem pair_0_1_range_0 : rangeCheck 0 8 (by decide)
    (fun p => pairLeftCheck certificate 0 1 p && pairRightCheck certificate 0 1 p) = true := by decide +kernel

#print axioms pair_0_1_range_0
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1
