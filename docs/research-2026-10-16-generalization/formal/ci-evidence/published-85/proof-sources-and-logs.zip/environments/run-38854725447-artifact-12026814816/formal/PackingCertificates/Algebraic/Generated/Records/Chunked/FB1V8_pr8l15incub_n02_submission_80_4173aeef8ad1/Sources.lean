import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (prism8_l15.normalizationCheck && (prism8_l15.verticesCheck && (cube.normalizationCheck && (cube.verticesCheck && cube.centroidCheck 1)))) = true
  simp only [prism8_l15_normalization_checked, prism8_l15_vertices_checked, cube_normalization_checked, cube_vertices_checked, cube_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr8l15incub_n02_submission_80_4173aeef8ad1
