import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0002
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0003
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0004
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0005
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0006
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02.Pair000_001_0007

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem pair_vertices_0_1 (p : Fin 62) :
    (pairLeftCheck certificate 0 1 p && pairRightCheck certificate 0 1 p) = true := by
  by_cases h32 : p.val < 32
  · by_cases h16 : p.val < 16
    · by_cases h8 : p.val < 8
      · exact rangeCheck_sound pair_0_1_range_0 p (by omega) (by omega)
      · exact rangeCheck_sound pair_0_1_range_1 p (by omega) (by omega)
    · by_cases h24 : p.val < 24
      · exact rangeCheck_sound pair_0_1_range_2 p (by omega) (by omega)
      · exact rangeCheck_sound pair_0_1_range_3 p (by omega) (by omega)
  · by_cases h48 : p.val < 48
    · by_cases h40 : p.val < 40
      · exact rangeCheck_sound pair_0_1_range_4 p (by omega) (by omega)
      · exact rangeCheck_sound pair_0_1_range_5 p (by omega) (by omega)
    · by_cases h56 : p.val < 56
      · exact rangeCheck_sound pair_0_1_range_6 p (by omega) (by omega)
      · exact rangeCheck_sound pair_0_1_range_7 p (by omega) (by omega)

theorem pair_0_1 : certificate.pairCheck 0 1 = true := by
  apply pairCheck_of_vertices
  · decide +kernel
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).1
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).2

#print axioms pair_0_1
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_dtcindtc_n02
