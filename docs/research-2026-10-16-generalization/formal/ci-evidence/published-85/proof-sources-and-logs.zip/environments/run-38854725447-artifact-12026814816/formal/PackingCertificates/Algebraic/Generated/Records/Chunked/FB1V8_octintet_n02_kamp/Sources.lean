import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (octahedron.normalizationCheck && (octahedron.verticesCheck && (tetrahedron.normalizationCheck && (tetrahedron.verticesCheck && tetrahedron.centroidCheck 2)))) = true
  simp only [octahedron_normalization_checked, octahedron_vertices_checked, tetrahedron_normalization_checked, tetrahedron_vertices_checked, tetrahedron_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp
