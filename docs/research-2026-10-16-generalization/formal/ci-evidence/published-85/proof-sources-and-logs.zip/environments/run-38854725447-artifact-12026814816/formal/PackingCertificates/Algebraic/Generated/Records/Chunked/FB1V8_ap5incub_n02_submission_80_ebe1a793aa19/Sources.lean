import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (antiprism5.normalizationCheck && (antiprism5.verticesCheck && (cube.normalizationCheck && (cube.verticesCheck && cube.centroidCheck 1)))) = true
  simp only [antiprism5_normalization_checked, antiprism5_vertices_checked, cube_normalization_checked, cube_vertices_checked, cube_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
