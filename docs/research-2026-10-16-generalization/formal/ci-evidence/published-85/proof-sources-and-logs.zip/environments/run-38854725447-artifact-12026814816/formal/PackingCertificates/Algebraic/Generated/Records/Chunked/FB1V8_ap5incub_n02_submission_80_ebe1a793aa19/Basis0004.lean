import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem bases_range_4 : rangeCheck 4 1 (by decide) (basisItemCheck certificate) = true := by decide +kernel

#print axioms bases_range_4
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_ap5incub_n02_submission_80_ebe1a793aa19
