import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp.Vertices001_0000

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_piece_1 (p : Fin 6) :
    (certificate.placedCheck 1 p && certificate.vertexContainmentCheck 1 p) = true := by
  exact rangeCheck_sound vertices_1_range_0 p (by omega) (by omega)

#print axioms vertices_piece_1
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_octintet_n02_kamp
