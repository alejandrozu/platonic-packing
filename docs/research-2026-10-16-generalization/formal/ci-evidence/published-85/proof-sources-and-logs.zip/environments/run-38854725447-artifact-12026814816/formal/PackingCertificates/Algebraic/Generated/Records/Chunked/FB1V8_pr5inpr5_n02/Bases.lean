import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0002
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0003
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0004
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0005
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0006
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0007
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02.Basis0008

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem bases_checked : certificate.basisCheck = true := by
  apply basisCheck_of_items
  intro z
  by_cases h4 : z.val < 4
  · by_cases h2 : z.val < 2
    · by_cases h1 : z.val < 1
      · exact rangeCheck_sound bases_range_0 z (by omega) (by omega)
      · exact rangeCheck_sound bases_range_1 z (by omega) (by omega)
    · by_cases h3 : z.val < 3
      · exact rangeCheck_sound bases_range_2 z (by omega) (by omega)
      · exact rangeCheck_sound bases_range_3 z (by omega) (by omega)
  · by_cases h6 : z.val < 6
    · by_cases h5 : z.val < 5
      · exact rangeCheck_sound bases_range_4 z (by omega) (by omega)
      · exact rangeCheck_sound bases_range_5 z (by omega) (by omega)
    · by_cases h7 : z.val < 7
      · exact rangeCheck_sound bases_range_6 z (by omega) (by omega)
      · by_cases h8 : z.val < 8
        · exact rangeCheck_sound bases_range_7 z (by omega) (by omega)
        · exact rangeCheck_sound bases_range_8 z (by omega) (by omega)

#print axioms bases_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_pr5inpr5_n02
