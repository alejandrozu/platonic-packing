import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubinico_n02.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubinico_n02
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (cube.normalizationCheck && (cube.verticesCheck && (icosahedron.normalizationCheck && (icosahedron.verticesCheck && icosahedron.centroidCheck 2)))) = true
  simp only [cube_normalization_checked, cube_vertices_checked, icosahedron_normalization_checked, icosahedron_vertices_checked, icosahedron_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cubinico_n02
