import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem source_checked : certificate.sourceCheck = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (cuboctahedron.normalizationCheck && (cuboctahedron.verticesCheck && (cuboctahedron.normalizationCheck && (cuboctahedron.verticesCheck && cuboctahedron.centroidCheck 2)))) = true
  simp only [cuboctahedron_normalization_checked, cuboctahedron_vertices_checked, cuboctahedron_centroid_checked] <;> rfl


#print axioms source_checked
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013
