import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Sources
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Bases
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Vertices000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Vertices001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013.Pair000_001

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D


theorem placements_checked : certificate.placementCheck = true := by
  apply placementCheck_of_vertices
  intro i p; fin_cases i
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_0 p)).1
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_1 p)).1

theorem containment_checked : certificate.containmentCheck = true := by
  apply containmentCheck_of_vertices
  intro i p; fin_cases i
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_0 p)).2
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_1 p)).2

theorem pairs_checked : certificate.pairsCheck = true := by
  apply pairsCheck_of_pairs
  intro i j hij; fin_cases i <;> fin_cases j <;> try (norm_num at hij)
  all_goals first
    | exact pair_0_1

theorem checked : certificate.check = true := by
  simp only [Certificate.check,source_checked,templates_checked,placements_checked,bases_checked,containment_checked,pairs_checked] <;> rfl

theorem valid : certificate.Valid := certificate.check_sound checked
theorem proper_orientation (i) : Matrix.det (fun a z => (certificate.rotation i a z : ℝ)) = 1 := certificate.proper_rotation checked i


#print axioms valid
#print axioms proper_orientation
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_cboincbo_n02_pingyou_20261013
