import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Vertices001_0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Vertices001_0001

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem vertices_piece_1 (p : Fin 12) :
    (certificate.placedCheck 1 p && certificate.vertexContainmentCheck 1 p) = true := by
  by_cases h8 : p.val < 8
  · exact rangeCheck_sound vertices_1_range_0 p (by omega) (by omega)
  · exact rangeCheck_sound vertices_1_range_1 p (by omega) (by omega)

#print axioms vertices_piece_1
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp
