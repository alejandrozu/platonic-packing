import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Data
import PackingCertificates.Algebraic.Fragment3D
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Basis0000
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Basis0001
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Basis0002
import PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp.Basis0003

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp
open PackingCertificates.Rational (allFin allFin_eq_true)
open PackingCertificates.Algebraic.Packing
open PackingCertificates.Algebraic.Fragment3D

theorem bases_checked : certificate.basisCheck = true := by
  apply basisCheck_of_items
  intro z
  by_cases h2 : z.val < 2
  · by_cases h1 : z.val < 1
    · exact rangeCheck_sound bases_range_0 z (by omega) (by omega)
    · exact rangeCheck_sound bases_range_1 z (by omega) (by omega)
  · by_cases h3 : z.val < 3
    · exact rangeCheck_sound bases_range_2 z (by omega) (by omega)
    · exact rangeCheck_sound bases_range_3 z (by omega) (by omega)

#print axioms bases_checked
end PackingCertificates.Algebraic.Generated.Records.Chunked.FB1V8_icoinoct_n02_kamp
