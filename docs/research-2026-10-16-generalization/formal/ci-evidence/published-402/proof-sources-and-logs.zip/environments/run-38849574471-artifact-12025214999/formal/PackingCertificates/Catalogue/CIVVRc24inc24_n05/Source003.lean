import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n05
open PackingCertificates.Rational

theorem source_piece_3 : Cayley.check (source (3 : Fin 5)) = true := by decide +kernel

theorem gram_piece_3 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (3 : Fin 5) a)
        (record.placement.rotation (3 : Fin 5) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_3 :
    allFin 5 (fun j => if (3 : Fin 5) < j then
      planeCheck (record.placement.toCertificate.vertices (3 : Fin 5))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (3 : Fin 5) j) else true) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.source_piece_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.gram_piece_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.pair_row_3
end PackingCertificates.Catalogue.CIVVRc24inc24_n05
