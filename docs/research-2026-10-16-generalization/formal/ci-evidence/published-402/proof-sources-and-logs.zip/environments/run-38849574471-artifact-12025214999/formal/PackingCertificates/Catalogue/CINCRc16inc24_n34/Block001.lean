import PackingCertificates.Catalogue.CINCRc16inc24_n34.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CINCRc16inc24_n34
open PackingCertificates.Rational

theorem source_piece_1 : Cayley.check (source (1 : Fin 34)) = true := by decide +kernel

theorem gram_piece_1 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (1 : Fin 34) a)
        (record.placement.rotation (1 : Fin 34) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_1 :
    allFin 34 (fun j => if (1 : Fin 34) < j then
      planeCheck (record.placement.toCertificate.vertices (1 : Fin 34))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (1 : Fin 34) j) else true) = true := by decide +kernel

theorem vertex_1_0 :
    record.vertexCheck (1 : Fin 34) (0 : Fin 8) = true := by decide +kernel

theorem vertex_1_1 :
    record.vertexCheck (1 : Fin 34) (1 : Fin 8) = true := by decide +kernel

theorem vertex_1_2 :
    record.vertexCheck (1 : Fin 34) (2 : Fin 8) = true := by decide +kernel

theorem vertex_1_3 :
    record.vertexCheck (1 : Fin 34) (3 : Fin 8) = true := by decide +kernel

theorem vertex_1_4 :
    record.vertexCheck (1 : Fin 34) (4 : Fin 8) = true := by decide +kernel

theorem vertex_1_5 :
    record.vertexCheck (1 : Fin 34) (5 : Fin 8) = true := by decide +kernel

theorem vertex_1_6 :
    record.vertexCheck (1 : Fin 34) (6 : Fin 8) = true := by decide +kernel

theorem vertex_1_7 :
    record.vertexCheck (1 : Fin 34) (7 : Fin 8) = true := by decide +kernel

theorem vertices_piece_1 :
    allFin 8 (fun p => record.vertexCheck (1 : Fin 34) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_1_0
  · exact vertex_1_1
  · exact vertex_1_2
  · exact vertex_1_3
  · exact vertex_1_4
  · exact vertex_1_5
  · exact vertex_1_6
  · exact vertex_1_7


#print axioms source_piece_1
#print axioms gram_piece_1
#print axioms pair_row_1
#print axioms vertices_piece_1
end PackingCertificates.Catalogue.CINCRc16inc24_n34
