import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex001_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex001_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex001_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertices_piece_1 :
    allFin 24 (fun p => record.vertexCheck (1 : Fin 17) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_1_0
  · exact vertex_1_1
  · exact vertex_1_2
  · exact vertex_1_3
  · exact vertex_1_4
  · exact vertex_1_5
  · exact vertex_1_6
  · exact vertex_1_7
  · exact vertex_1_8
  · exact vertex_1_9
  · exact vertex_1_10
  · exact vertex_1_11
  · exact vertex_1_12
  · exact vertex_1_13
  · exact vertex_1_14
  · exact vertex_1_15
  · exact vertex_1_16
  · exact vertex_1_17
  · exact vertex_1_18
  · exact vertex_1_19
  · exact vertex_1_20
  · exact vertex_1_21
  · exact vertex_1_22
  · exact vertex_1_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertices_piece_1
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
