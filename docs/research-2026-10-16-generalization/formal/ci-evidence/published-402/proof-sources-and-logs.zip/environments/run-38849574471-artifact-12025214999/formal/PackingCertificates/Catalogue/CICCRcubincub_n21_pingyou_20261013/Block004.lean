import PackingCertificates.Catalogue.CICCRcubincub_n21_pingyou_20261013.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CICCRcubincub_n21_pingyou_20261013
open PackingCertificates.Rational
open PackingCertificates.CubeFast

theorem source_piece_20 :
    (decide (0 < Cube.quaternionNormSq (record.quaternion (20 : Fin 21))) && decide (record.rotation (20 : Fin 21) = Cube.quaternionMatrix (record.quaternion (20 : Fin 21))) && decide (Cube.determinant3 (record.rotation (20 : Fin 21)) = 1)) = true := by decide +kernel

theorem gram_piece_20 :
    allFin 3 (fun a => allFin 3 (fun b => decide (qdot (record.toPlacement.rotation (20 : Fin 21) a) (record.toPlacement.rotation (20 : Fin 21) b) = if a = b then 1 else 0))) = true := by decide +kernel

theorem cache_row_20 :
    AxisFast.cacheRowCheck record cache (20 : Fin 21) = true := by decide +kernel

theorem wall_row_20 : CubeFast.wallRowCheck record (20 : Fin 21) = true := by decide +kernel

theorem pair_row_20 :
    AxisFast.pairRowCheck record cache directions (20 : Fin 21) = true := by decide +kernel

#print axioms source_piece_20
#print axioms gram_piece_20
#print axioms cache_row_20
#print axioms wall_row_20
#print axioms pair_row_20
end PackingCertificates.Catalogue.CICCRcubincub_n21_pingyou_20261013
