import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n05
open PackingCertificates.Rational

theorem vertex_2_16 :
    record.vertexCheck (2 : Fin 5) (16 : Fin 24) = true := by decide +kernel


theorem vertex_2_17 :
    record.vertexCheck (2 : Fin 5) (17 : Fin 24) = true := by decide +kernel


theorem vertex_2_18 :
    record.vertexCheck (2 : Fin 5) (18 : Fin 24) = true := by decide +kernel


theorem vertex_2_19 :
    record.vertexCheck (2 : Fin 5) (19 : Fin 24) = true := by decide +kernel


theorem vertex_2_20 :
    record.vertexCheck (2 : Fin 5) (20 : Fin 24) = true := by decide +kernel


theorem vertex_2_21 :
    record.vertexCheck (2 : Fin 5) (21 : Fin 24) = true := by decide +kernel


theorem vertex_2_22 :
    record.vertexCheck (2 : Fin 5) (22 : Fin 24) = true := by decide +kernel


theorem vertex_2_23 :
    record.vertexCheck (2 : Fin 5) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_2_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n05
