import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_0_16 :
    record.vertexCheck (0 : Fin 17) (16 : Fin 24) = true := by decide +kernel


theorem vertex_0_17 :
    record.vertexCheck (0 : Fin 17) (17 : Fin 24) = true := by decide +kernel


theorem vertex_0_18 :
    record.vertexCheck (0 : Fin 17) (18 : Fin 24) = true := by decide +kernel


theorem vertex_0_19 :
    record.vertexCheck (0 : Fin 17) (19 : Fin 24) = true := by decide +kernel


theorem vertex_0_20 :
    record.vertexCheck (0 : Fin 17) (20 : Fin 24) = true := by decide +kernel


theorem vertex_0_21 :
    record.vertexCheck (0 : Fin 17) (21 : Fin 24) = true := by decide +kernel


theorem vertex_0_22 :
    record.vertexCheck (0 : Fin 17) (22 : Fin 24) = true := by decide +kernel


theorem vertex_0_23 :
    record.vertexCheck (0 : Fin 17) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
