import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_15_16 :
    record.vertexCheck (15 : Fin 17) (16 : Fin 24) = true := by decide +kernel


theorem vertex_15_17 :
    record.vertexCheck (15 : Fin 17) (17 : Fin 24) = true := by decide +kernel


theorem vertex_15_18 :
    record.vertexCheck (15 : Fin 17) (18 : Fin 24) = true := by decide +kernel


theorem vertex_15_19 :
    record.vertexCheck (15 : Fin 17) (19 : Fin 24) = true := by decide +kernel


theorem vertex_15_20 :
    record.vertexCheck (15 : Fin 17) (20 : Fin 24) = true := by decide +kernel


theorem vertex_15_21 :
    record.vertexCheck (15 : Fin 17) (21 : Fin 24) = true := by decide +kernel


theorem vertex_15_22 :
    record.vertexCheck (15 : Fin 17) (22 : Fin 24) = true := by decide +kernel


theorem vertex_15_23 :
    record.vertexCheck (15 : Fin 17) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_15_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
