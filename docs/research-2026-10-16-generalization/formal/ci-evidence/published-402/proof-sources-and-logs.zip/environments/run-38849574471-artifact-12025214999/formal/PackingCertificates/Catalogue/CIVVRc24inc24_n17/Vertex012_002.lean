import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_12_16 :
    record.vertexCheck (12 : Fin 17) (16 : Fin 24) = true := by decide +kernel


theorem vertex_12_17 :
    record.vertexCheck (12 : Fin 17) (17 : Fin 24) = true := by decide +kernel


theorem vertex_12_18 :
    record.vertexCheck (12 : Fin 17) (18 : Fin 24) = true := by decide +kernel


theorem vertex_12_19 :
    record.vertexCheck (12 : Fin 17) (19 : Fin 24) = true := by decide +kernel


theorem vertex_12_20 :
    record.vertexCheck (12 : Fin 17) (20 : Fin 24) = true := by decide +kernel


theorem vertex_12_21 :
    record.vertexCheck (12 : Fin 17) (21 : Fin 24) = true := by decide +kernel


theorem vertex_12_22 :
    record.vertexCheck (12 : Fin 17) (22 : Fin 24) = true := by decide +kernel


theorem vertex_12_23 :
    record.vertexCheck (12 : Fin 17) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_12_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
