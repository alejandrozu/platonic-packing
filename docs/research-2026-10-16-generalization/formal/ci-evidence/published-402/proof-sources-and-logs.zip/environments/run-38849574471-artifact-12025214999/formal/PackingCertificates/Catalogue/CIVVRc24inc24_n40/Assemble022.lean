import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex022_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex022_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex022_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_22 :
    allFin 24 (fun p => record.vertexCheck (22 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_22_0
  · exact vertex_22_1
  · exact vertex_22_2
  · exact vertex_22_3
  · exact vertex_22_4
  · exact vertex_22_5
  · exact vertex_22_6
  · exact vertex_22_7
  · exact vertex_22_8
  · exact vertex_22_9
  · exact vertex_22_10
  · exact vertex_22_11
  · exact vertex_22_12
  · exact vertex_22_13
  · exact vertex_22_14
  · exact vertex_22_15
  · exact vertex_22_16
  · exact vertex_22_17
  · exact vertex_22_18
  · exact vertex_22_19
  · exact vertex_22_20
  · exact vertex_22_21
  · exact vertex_22_22
  · exact vertex_22_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_22
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
