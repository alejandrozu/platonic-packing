import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_7_8 :
    record.vertexCheck (7 : Fin 40) (8 : Fin 24) = true := by decide +kernel


theorem vertex_7_9 :
    record.vertexCheck (7 : Fin 40) (9 : Fin 24) = true := by decide +kernel


theorem vertex_7_10 :
    record.vertexCheck (7 : Fin 40) (10 : Fin 24) = true := by decide +kernel


theorem vertex_7_11 :
    record.vertexCheck (7 : Fin 40) (11 : Fin 24) = true := by decide +kernel


theorem vertex_7_12 :
    record.vertexCheck (7 : Fin 40) (12 : Fin 24) = true := by decide +kernel


theorem vertex_7_13 :
    record.vertexCheck (7 : Fin 40) (13 : Fin 24) = true := by decide +kernel


theorem vertex_7_14 :
    record.vertexCheck (7 : Fin 40) (14 : Fin 24) = true := by decide +kernel


theorem vertex_7_15 :
    record.vertexCheck (7 : Fin 40) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_7_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
