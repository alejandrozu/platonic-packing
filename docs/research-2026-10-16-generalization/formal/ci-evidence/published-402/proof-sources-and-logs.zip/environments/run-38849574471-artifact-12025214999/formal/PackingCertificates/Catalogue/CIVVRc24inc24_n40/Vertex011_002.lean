import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_11_16 :
    record.vertexCheck (11 : Fin 40) (16 : Fin 24) = true := by decide +kernel


theorem vertex_11_17 :
    record.vertexCheck (11 : Fin 40) (17 : Fin 24) = true := by decide +kernel


theorem vertex_11_18 :
    record.vertexCheck (11 : Fin 40) (18 : Fin 24) = true := by decide +kernel


theorem vertex_11_19 :
    record.vertexCheck (11 : Fin 40) (19 : Fin 24) = true := by decide +kernel


theorem vertex_11_20 :
    record.vertexCheck (11 : Fin 40) (20 : Fin 24) = true := by decide +kernel


theorem vertex_11_21 :
    record.vertexCheck (11 : Fin 40) (21 : Fin 24) = true := by decide +kernel


theorem vertex_11_22 :
    record.vertexCheck (11 : Fin 40) (22 : Fin 24) = true := by decide +kernel


theorem vertex_11_23 :
    record.vertexCheck (11 : Fin 40) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_11_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
