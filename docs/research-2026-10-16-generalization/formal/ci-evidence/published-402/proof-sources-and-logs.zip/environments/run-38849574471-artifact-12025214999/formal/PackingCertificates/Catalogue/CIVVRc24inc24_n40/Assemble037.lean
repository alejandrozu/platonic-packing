import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex037_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex037_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex037_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_37 :
    allFin 24 (fun p => record.vertexCheck (37 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_37_0
  · exact vertex_37_1
  · exact vertex_37_2
  · exact vertex_37_3
  · exact vertex_37_4
  · exact vertex_37_5
  · exact vertex_37_6
  · exact vertex_37_7
  · exact vertex_37_8
  · exact vertex_37_9
  · exact vertex_37_10
  · exact vertex_37_11
  · exact vertex_37_12
  · exact vertex_37_13
  · exact vertex_37_14
  · exact vertex_37_15
  · exact vertex_37_16
  · exact vertex_37_17
  · exact vertex_37_18
  · exact vertex_37_19
  · exact vertex_37_20
  · exact vertex_37_21
  · exact vertex_37_22
  · exact vertex_37_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_37
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
