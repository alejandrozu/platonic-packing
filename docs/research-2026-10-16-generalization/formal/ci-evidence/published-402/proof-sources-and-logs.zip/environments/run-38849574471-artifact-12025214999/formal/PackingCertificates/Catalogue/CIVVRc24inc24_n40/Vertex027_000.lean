import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_27_0 :
    record.vertexCheck (27 : Fin 40) (0 : Fin 24) = true := by decide +kernel


theorem vertex_27_1 :
    record.vertexCheck (27 : Fin 40) (1 : Fin 24) = true := by decide +kernel


theorem vertex_27_2 :
    record.vertexCheck (27 : Fin 40) (2 : Fin 24) = true := by decide +kernel


theorem vertex_27_3 :
    record.vertexCheck (27 : Fin 40) (3 : Fin 24) = true := by decide +kernel


theorem vertex_27_4 :
    record.vertexCheck (27 : Fin 40) (4 : Fin 24) = true := by decide +kernel


theorem vertex_27_5 :
    record.vertexCheck (27 : Fin 40) (5 : Fin 24) = true := by decide +kernel


theorem vertex_27_6 :
    record.vertexCheck (27 : Fin 40) (6 : Fin 24) = true := by decide +kernel


theorem vertex_27_7 :
    record.vertexCheck (27 : Fin 40) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_27_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
