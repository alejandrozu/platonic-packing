import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem source_piece_16 : Cayley.check (source (16 : Fin 17)) = true := by decide +kernel

theorem gram_piece_16 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (16 : Fin 17) a)
        (record.placement.rotation (16 : Fin 17) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_16 :
    allFin 17 (fun j => if (16 : Fin 17) < j then
      planeCheck (record.placement.toCertificate.vertices (16 : Fin 17))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (16 : Fin 17) j) else true) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.source_piece_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.gram_piece_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.pair_row_16
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
