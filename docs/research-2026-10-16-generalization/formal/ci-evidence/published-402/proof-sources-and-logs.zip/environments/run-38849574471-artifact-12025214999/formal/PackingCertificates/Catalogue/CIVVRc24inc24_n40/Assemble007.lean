import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex007_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex007_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex007_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_7 :
    allFin 24 (fun p => record.vertexCheck (7 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_7_0
  · exact vertex_7_1
  · exact vertex_7_2
  · exact vertex_7_3
  · exact vertex_7_4
  · exact vertex_7_5
  · exact vertex_7_6
  · exact vertex_7_7
  · exact vertex_7_8
  · exact vertex_7_9
  · exact vertex_7_10
  · exact vertex_7_11
  · exact vertex_7_12
  · exact vertex_7_13
  · exact vertex_7_14
  · exact vertex_7_15
  · exact vertex_7_16
  · exact vertex_7_17
  · exact vertex_7_18
  · exact vertex_7_19
  · exact vertex_7_20
  · exact vertex_7_21
  · exact vertex_7_22
  · exact vertex_7_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
