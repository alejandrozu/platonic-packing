import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex012_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex012_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex012_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertices_piece_12 :
    allFin 24 (fun p => record.vertexCheck (12 : Fin 17) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_12_0
  · exact vertex_12_1
  · exact vertex_12_2
  · exact vertex_12_3
  · exact vertex_12_4
  · exact vertex_12_5
  · exact vertex_12_6
  · exact vertex_12_7
  · exact vertex_12_8
  · exact vertex_12_9
  · exact vertex_12_10
  · exact vertex_12_11
  · exact vertex_12_12
  · exact vertex_12_13
  · exact vertex_12_14
  · exact vertex_12_15
  · exact vertex_12_16
  · exact vertex_12_17
  · exact vertex_12_18
  · exact vertex_12_19
  · exact vertex_12_20
  · exact vertex_12_21
  · exact vertex_12_22
  · exact vertex_12_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertices_piece_12
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
