import PackingCertificates.Catalogue.CINCRc16inc24_n14.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CINCRc16inc24_n14
open PackingCertificates.Rational

theorem source_piece_2 : Cayley.check (source (2 : Fin 14)) = true := by decide +kernel

theorem gram_piece_2 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (2 : Fin 14) a)
        (record.placement.rotation (2 : Fin 14) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_2 :
    allFin 14 (fun j => if (2 : Fin 14) < j then
      planeCheck (record.placement.toCertificate.vertices (2 : Fin 14))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (2 : Fin 14) j) else true) = true := by decide +kernel

theorem vertex_2_0 :
    record.vertexCheck (2 : Fin 14) (0 : Fin 8) = true := by decide +kernel

theorem vertex_2_1 :
    record.vertexCheck (2 : Fin 14) (1 : Fin 8) = true := by decide +kernel

theorem vertex_2_2 :
    record.vertexCheck (2 : Fin 14) (2 : Fin 8) = true := by decide +kernel

theorem vertex_2_3 :
    record.vertexCheck (2 : Fin 14) (3 : Fin 8) = true := by decide +kernel

theorem vertex_2_4 :
    record.vertexCheck (2 : Fin 14) (4 : Fin 8) = true := by decide +kernel

theorem vertex_2_5 :
    record.vertexCheck (2 : Fin 14) (5 : Fin 8) = true := by decide +kernel

theorem vertex_2_6 :
    record.vertexCheck (2 : Fin 14) (6 : Fin 8) = true := by decide +kernel

theorem vertex_2_7 :
    record.vertexCheck (2 : Fin 14) (7 : Fin 8) = true := by decide +kernel

theorem vertices_piece_2 :
    allFin 8 (fun p => record.vertexCheck (2 : Fin 14) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_2_0
  · exact vertex_2_1
  · exact vertex_2_2
  · exact vertex_2_3
  · exact vertex_2_4
  · exact vertex_2_5
  · exact vertex_2_6
  · exact vertex_2_7


#print axioms source_piece_2
#print axioms gram_piece_2
#print axioms pair_row_2
#print axioms vertices_piece_2
end PackingCertificates.Catalogue.CINCRc16inc24_n14
