import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex027_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex027_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex027_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_27 :
    allFin 24 (fun p => record.vertexCheck (27 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_27_0
  · exact vertex_27_1
  · exact vertex_27_2
  · exact vertex_27_3
  · exact vertex_27_4
  · exact vertex_27_5
  · exact vertex_27_6
  · exact vertex_27_7
  · exact vertex_27_8
  · exact vertex_27_9
  · exact vertex_27_10
  · exact vertex_27_11
  · exact vertex_27_12
  · exact vertex_27_13
  · exact vertex_27_14
  · exact vertex_27_15
  · exact vertex_27_16
  · exact vertex_27_17
  · exact vertex_27_18
  · exact vertex_27_19
  · exact vertex_27_20
  · exact vertex_27_21
  · exact vertex_27_22
  · exact vertex_27_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_27
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
