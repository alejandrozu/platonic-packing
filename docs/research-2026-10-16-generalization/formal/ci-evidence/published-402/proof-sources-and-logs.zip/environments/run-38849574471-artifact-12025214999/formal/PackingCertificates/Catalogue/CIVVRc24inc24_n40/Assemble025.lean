import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex025_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex025_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex025_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_25 :
    allFin 24 (fun p => record.vertexCheck (25 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_25_0
  · exact vertex_25_1
  · exact vertex_25_2
  · exact vertex_25_3
  · exact vertex_25_4
  · exact vertex_25_5
  · exact vertex_25_6
  · exact vertex_25_7
  · exact vertex_25_8
  · exact vertex_25_9
  · exact vertex_25_10
  · exact vertex_25_11
  · exact vertex_25_12
  · exact vertex_25_13
  · exact vertex_25_14
  · exact vertex_25_15
  · exact vertex_25_16
  · exact vertex_25_17
  · exact vertex_25_18
  · exact vertex_25_19
  · exact vertex_25_20
  · exact vertex_25_21
  · exact vertex_25_22
  · exact vertex_25_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_25
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
