import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_17_16 :
    record.vertexCheck (17 : Fin 40) (16 : Fin 24) = true := by decide +kernel


theorem vertex_17_17 :
    record.vertexCheck (17 : Fin 40) (17 : Fin 24) = true := by decide +kernel


theorem vertex_17_18 :
    record.vertexCheck (17 : Fin 40) (18 : Fin 24) = true := by decide +kernel


theorem vertex_17_19 :
    record.vertexCheck (17 : Fin 40) (19 : Fin 24) = true := by decide +kernel


theorem vertex_17_20 :
    record.vertexCheck (17 : Fin 40) (20 : Fin 24) = true := by decide +kernel


theorem vertex_17_21 :
    record.vertexCheck (17 : Fin 40) (21 : Fin 24) = true := by decide +kernel


theorem vertex_17_22 :
    record.vertexCheck (17 : Fin 40) (22 : Fin 24) = true := by decide +kernel


theorem vertex_17_23 :
    record.vertexCheck (17 : Fin 40) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
