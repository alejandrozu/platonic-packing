import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex005_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex005_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex005_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem vertices_piece_5 :
    allFin 24 (fun p => record.vertexCheck (5 : Fin 6) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_5_0
  · exact vertex_5_1
  · exact vertex_5_2
  · exact vertex_5_3
  · exact vertex_5_4
  · exact vertex_5_5
  · exact vertex_5_6
  · exact vertex_5_7
  · exact vertex_5_8
  · exact vertex_5_9
  · exact vertex_5_10
  · exact vertex_5_11
  · exact vertex_5_12
  · exact vertex_5_13
  · exact vertex_5_14
  · exact vertex_5_15
  · exact vertex_5_16
  · exact vertex_5_17
  · exact vertex_5_18
  · exact vertex_5_19
  · exact vertex_5_20
  · exact vertex_5_21
  · exact vertex_5_22
  · exact vertex_5_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertices_piece_5
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
