import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem vertex_4_16 :
    record.vertexCheck (4 : Fin 6) (16 : Fin 24) = true := by decide +kernel


theorem vertex_4_17 :
    record.vertexCheck (4 : Fin 6) (17 : Fin 24) = true := by decide +kernel


theorem vertex_4_18 :
    record.vertexCheck (4 : Fin 6) (18 : Fin 24) = true := by decide +kernel


theorem vertex_4_19 :
    record.vertexCheck (4 : Fin 6) (19 : Fin 24) = true := by decide +kernel


theorem vertex_4_20 :
    record.vertexCheck (4 : Fin 6) (20 : Fin 24) = true := by decide +kernel


theorem vertex_4_21 :
    record.vertexCheck (4 : Fin 6) (21 : Fin 24) = true := by decide +kernel


theorem vertex_4_22 :
    record.vertexCheck (4 : Fin 6) (22 : Fin 24) = true := by decide +kernel


theorem vertex_4_23 :
    record.vertexCheck (4 : Fin 6) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_4_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
