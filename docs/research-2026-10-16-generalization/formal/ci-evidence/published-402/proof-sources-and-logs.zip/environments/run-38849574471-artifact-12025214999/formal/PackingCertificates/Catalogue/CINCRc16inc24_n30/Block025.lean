import PackingCertificates.Catalogue.CINCRc16inc24_n30.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CINCRc16inc24_n30
open PackingCertificates.Rational

theorem source_piece_25 : Cayley.check (source (25 : Fin 30)) = true := by decide +kernel

theorem gram_piece_25 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (25 : Fin 30) a)
        (record.placement.rotation (25 : Fin 30) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_25 :
    allFin 30 (fun j => if (25 : Fin 30) < j then
      planeCheck (record.placement.toCertificate.vertices (25 : Fin 30))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (25 : Fin 30) j) else true) = true := by decide +kernel

theorem vertex_25_0 :
    record.vertexCheck (25 : Fin 30) (0 : Fin 8) = true := by decide +kernel

theorem vertex_25_1 :
    record.vertexCheck (25 : Fin 30) (1 : Fin 8) = true := by decide +kernel

theorem vertex_25_2 :
    record.vertexCheck (25 : Fin 30) (2 : Fin 8) = true := by decide +kernel

theorem vertex_25_3 :
    record.vertexCheck (25 : Fin 30) (3 : Fin 8) = true := by decide +kernel

theorem vertex_25_4 :
    record.vertexCheck (25 : Fin 30) (4 : Fin 8) = true := by decide +kernel

theorem vertex_25_5 :
    record.vertexCheck (25 : Fin 30) (5 : Fin 8) = true := by decide +kernel

theorem vertex_25_6 :
    record.vertexCheck (25 : Fin 30) (6 : Fin 8) = true := by decide +kernel

theorem vertex_25_7 :
    record.vertexCheck (25 : Fin 30) (7 : Fin 8) = true := by decide +kernel

theorem vertices_piece_25 :
    allFin 8 (fun p => record.vertexCheck (25 : Fin 30) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_25_0
  · exact vertex_25_1
  · exact vertex_25_2
  · exact vertex_25_3
  · exact vertex_25_4
  · exact vertex_25_5
  · exact vertex_25_6
  · exact vertex_25_7


#print axioms source_piece_25
#print axioms gram_piece_25
#print axioms pair_row_25
#print axioms vertices_piece_25
end PackingCertificates.Catalogue.CINCRc16inc24_n30
