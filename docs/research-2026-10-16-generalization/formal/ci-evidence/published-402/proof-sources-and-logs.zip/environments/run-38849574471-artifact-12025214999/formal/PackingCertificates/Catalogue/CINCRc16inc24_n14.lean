import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block000
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block001
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block002
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block003
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block004
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block005
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block006
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block007
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block008
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block009
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block010
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block011
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block012
import PackingCertificates.Catalogue.CINCRc16inc24_n14.Block013

-- Original source: records/c16inc24/c16inc24_n14.json
-- Original JSON SHA256: a753bfa6f4438396ada3479183a8cd480e2430c6d3bd2b57a85401ae21e47053
-- Canonical geometry SHA256: 668f2e176e56e11738722784a6286784151479f24820db13910bd627627b596e
-- Record identifier: c16inc24_n14
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CINCRc16inc24_n14
open PackingCertificates.Rational

theorem source_checked : allFin 14 (fun i => Cayley.check (source i)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact source_piece_0
  · exact source_piece_1
  · exact source_piece_2
  · exact source_piece_3
  · exact source_piece_4
  · exact source_piece_5
  · exact source_piece_6
  · exact source_piece_7
  · exact source_piece_8
  · exact source_piece_9
  · exact source_piece_10
  · exact source_piece_11
  · exact source_piece_12
  · exact source_piece_13

theorem gram_checked_all : allFin 14 (fun i => allFin 4 (fun a => allFin 4 (fun b => decide (qdot (record.placement.rotation i a) (record.placement.rotation i b) = if a = b then 1 else 0)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact gram_piece_0
  · exact gram_piece_1
  · exact gram_piece_2
  · exact gram_piece_3
  · exact gram_piece_4
  · exact gram_piece_5
  · exact gram_piece_6
  · exact gram_piece_7
  · exact gram_piece_8
  · exact gram_piece_9
  · exact gram_piece_10
  · exact gram_piece_11
  · exact gram_piece_12
  · exact gram_piece_13

theorem pair_checked : allFin 14 (fun i => allFin 14 (fun j => if i < j then planeCheck (record.placement.toCertificate.vertices i) (record.placement.toCertificate.vertices j) (record.placement.separation i j) else true)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact pair_row_0
  · exact pair_row_1
  · exact pair_row_2
  · exact pair_row_3
  · exact pair_row_4
  · exact pair_row_5
  · exact pair_row_6
  · exact pair_row_7
  · exact pair_row_8
  · exact pair_row_9
  · exact pair_row_10
  · exact pair_row_11
  · exact pair_row_12
  · exact pair_row_13

theorem vertices_checked : allFin 14 (fun i => allFin 8 (fun p => record.vertexCheck i p)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact vertices_piece_0
  · exact vertices_piece_1
  · exact vertices_piece_2
  · exact vertices_piece_3
  · exact vertices_piece_4
  · exact vertices_piece_5
  · exact vertices_piece_6
  · exact vertices_piece_7
  · exact vertices_piece_8
  · exact vertices_piece_9
  · exact vertices_piece_10
  · exact vertices_piece_11
  · exact vertices_piece_12
  · exact vertices_piece_13

theorem source_valid : ∀ i, Cayley.Valid (source i) := by
  intro i
  exact Cayley.check_sound _ (allFin_eq_true.mp source_checked i)

theorem gram_checked : orthogonalCheck record.placement = true := gram_checked_all

theorem walls_checked :
    allFin 14 (fun i => allFin 8 (fun p => allFin 0 (fun f =>
      decide (qdot (record.placement.toCertificate.walls f).normal
        (record.placement.toCertificate.vertices i p) ≤
          (record.placement.toCertificate.walls f).offset)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  apply allFin_eq_true.mpr
  intro p
  apply allFin_eq_true.mpr
  intro f
  exact Fin.elim0 f

theorem rational_checked : Rational.check record.placement.toCertificate = true := by
  simp only [Rational.check, Bool.and_eq_true]
  exact ⟨walls_checked, pair_checked⟩

theorem placed_checked : checkPlaced record.placement = true := by
  simp only [checkPlaced, Bool.and_eq_true]
  exact ⟨gram_checked, rational_checked⟩

theorem scale_checked : decide (0 < record.scale) = true := by decide +kernel

theorem checked : Barycentric.check record = true := by
  simp only [Barycentric.check, Bool.and_eq_true]
  exact ⟨⟨placed_checked, scale_checked⟩, vertices_checked⟩

/-- Complete convex-polytope packing, assembled from kernel-checked fragments. -/
theorem packing : Barycentric.Valid record := Barycentric.check_sound record checked

theorem proper_orientation : ∀ i : Fin 14,
    Matrix.det (fun a b => (record.placement.rotation i a b : ℝ)) = 1 := by
  intro i
  exact Cayley.determinant_real (source i) (allFin_eq_true.mp source_checked i)

#print axioms source_valid
#print axioms packing
#print axioms proper_orientation
end PackingCertificates.Catalogue.CINCRc16inc24_n14
