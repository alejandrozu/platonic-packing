import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem source_piece_14 : Cayley.check (source (14 : Fin 17)) = true := by decide +kernel

theorem gram_piece_14 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (14 : Fin 17) a)
        (record.placement.rotation (14 : Fin 17) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_14 :
    allFin 17 (fun j => if (14 : Fin 17) < j then
      planeCheck (record.placement.toCertificate.vertices (14 : Fin 17))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (14 : Fin 17) j) else true) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.source_piece_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.gram_piece_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.pair_row_14
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
