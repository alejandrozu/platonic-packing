import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex002_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex002_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex002_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_2 :
    allFin 24 (fun p => record.vertexCheck (2 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_2_0
  · exact vertex_2_1
  · exact vertex_2_2
  · exact vertex_2_3
  · exact vertex_2_4
  · exact vertex_2_5
  · exact vertex_2_6
  · exact vertex_2_7
  · exact vertex_2_8
  · exact vertex_2_9
  · exact vertex_2_10
  · exact vertex_2_11
  · exact vertex_2_12
  · exact vertex_2_13
  · exact vertex_2_14
  · exact vertex_2_15
  · exact vertex_2_16
  · exact vertex_2_17
  · exact vertex_2_18
  · exact vertex_2_19
  · exact vertex_2_20
  · exact vertex_2_21
  · exact vertex_2_22
  · exact vertex_2_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_2
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
