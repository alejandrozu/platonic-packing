import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex029_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex029_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex029_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_29 :
    allFin 24 (fun p => record.vertexCheck (29 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_29_0
  · exact vertex_29_1
  · exact vertex_29_2
  · exact vertex_29_3
  · exact vertex_29_4
  · exact vertex_29_5
  · exact vertex_29_6
  · exact vertex_29_7
  · exact vertex_29_8
  · exact vertex_29_9
  · exact vertex_29_10
  · exact vertex_29_11
  · exact vertex_29_12
  · exact vertex_29_13
  · exact vertex_29_14
  · exact vertex_29_15
  · exact vertex_29_16
  · exact vertex_29_17
  · exact vertex_29_18
  · exact vertex_29_19
  · exact vertex_29_20
  · exact vertex_29_21
  · exact vertex_29_22
  · exact vertex_29_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_29
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
