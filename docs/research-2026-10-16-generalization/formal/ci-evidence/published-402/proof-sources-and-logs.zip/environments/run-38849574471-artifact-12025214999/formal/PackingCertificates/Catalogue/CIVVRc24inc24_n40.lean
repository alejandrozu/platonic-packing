import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source002
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble002
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source003
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble003
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source004
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble004
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source005
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble005
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source006
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble006
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source007
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble007
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source008
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble008
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source009
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble009
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source010
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble010
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source011
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble011
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source012
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble012
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source013
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble013
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source014
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble014
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source015
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble015
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source016
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble016
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source017
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble017
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source018
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble018
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source019
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble019
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source020
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble020
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source021
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble021
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source022
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble022
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source023
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble023
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source024
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble024
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source025
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble025
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source026
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble026
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source027
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble027
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source028
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble028
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source029
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble029
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source030
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble030
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source031
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble031
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source032
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble032
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source033
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble033
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source034
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble034
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source035
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble035
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source036
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble036
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source037
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble037
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source038
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble038
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Source039
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Assemble039

-- Original source: records/c24inc24/c24inc24_n40.json
-- Original JSON SHA256: 7f55569c15b0f2d0bd47cc319890b13b7bde09ac37ff66309c599944835a3bd5
-- Canonical geometry SHA256: 668f2e176e56e11738722784a6286784151479f24820db13910bd627627b596e
-- Record identifier: c24inc24_n40
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem source_checked : allFin 40 (fun i => Cayley.check (source i)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact source_piece_0
  · exact source_piece_1
  · exact source_piece_2
  · exact source_piece_3
  · exact source_piece_4
  · exact source_piece_5
  · exact source_piece_6
  · exact source_piece_7
  · exact source_piece_8
  · exact source_piece_9
  · exact source_piece_10
  · exact source_piece_11
  · exact source_piece_12
  · exact source_piece_13
  · exact source_piece_14
  · exact source_piece_15
  · exact source_piece_16
  · exact source_piece_17
  · exact source_piece_18
  · exact source_piece_19
  · exact source_piece_20
  · exact source_piece_21
  · exact source_piece_22
  · exact source_piece_23
  · exact source_piece_24
  · exact source_piece_25
  · exact source_piece_26
  · exact source_piece_27
  · exact source_piece_28
  · exact source_piece_29
  · exact source_piece_30
  · exact source_piece_31
  · exact source_piece_32
  · exact source_piece_33
  · exact source_piece_34
  · exact source_piece_35
  · exact source_piece_36
  · exact source_piece_37
  · exact source_piece_38
  · exact source_piece_39

theorem gram_checked_all : allFin 40 (fun i => allFin 4 (fun a => allFin 4 (fun b => decide (qdot (record.placement.rotation i a) (record.placement.rotation i b) = if a = b then 1 else 0)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact gram_piece_0
  · exact gram_piece_1
  · exact gram_piece_2
  · exact gram_piece_3
  · exact gram_piece_4
  · exact gram_piece_5
  · exact gram_piece_6
  · exact gram_piece_7
  · exact gram_piece_8
  · exact gram_piece_9
  · exact gram_piece_10
  · exact gram_piece_11
  · exact gram_piece_12
  · exact gram_piece_13
  · exact gram_piece_14
  · exact gram_piece_15
  · exact gram_piece_16
  · exact gram_piece_17
  · exact gram_piece_18
  · exact gram_piece_19
  · exact gram_piece_20
  · exact gram_piece_21
  · exact gram_piece_22
  · exact gram_piece_23
  · exact gram_piece_24
  · exact gram_piece_25
  · exact gram_piece_26
  · exact gram_piece_27
  · exact gram_piece_28
  · exact gram_piece_29
  · exact gram_piece_30
  · exact gram_piece_31
  · exact gram_piece_32
  · exact gram_piece_33
  · exact gram_piece_34
  · exact gram_piece_35
  · exact gram_piece_36
  · exact gram_piece_37
  · exact gram_piece_38
  · exact gram_piece_39

theorem pair_checked : allFin 40 (fun i => allFin 40 (fun j => if i < j then planeCheck (record.placement.toCertificate.vertices i) (record.placement.toCertificate.vertices j) (record.placement.separation i j) else true)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact pair_row_0
  · exact pair_row_1
  · exact pair_row_2
  · exact pair_row_3
  · exact pair_row_4
  · exact pair_row_5
  · exact pair_row_6
  · exact pair_row_7
  · exact pair_row_8
  · exact pair_row_9
  · exact pair_row_10
  · exact pair_row_11
  · exact pair_row_12
  · exact pair_row_13
  · exact pair_row_14
  · exact pair_row_15
  · exact pair_row_16
  · exact pair_row_17
  · exact pair_row_18
  · exact pair_row_19
  · exact pair_row_20
  · exact pair_row_21
  · exact pair_row_22
  · exact pair_row_23
  · exact pair_row_24
  · exact pair_row_25
  · exact pair_row_26
  · exact pair_row_27
  · exact pair_row_28
  · exact pair_row_29
  · exact pair_row_30
  · exact pair_row_31
  · exact pair_row_32
  · exact pair_row_33
  · exact pair_row_34
  · exact pair_row_35
  · exact pair_row_36
  · exact pair_row_37
  · exact pair_row_38
  · exact pair_row_39

theorem vertices_checked : allFin 40 (fun i => allFin 24 (fun p => record.vertexCheck i p)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact vertices_piece_0
  · exact vertices_piece_1
  · exact vertices_piece_2
  · exact vertices_piece_3
  · exact vertices_piece_4
  · exact vertices_piece_5
  · exact vertices_piece_6
  · exact vertices_piece_7
  · exact vertices_piece_8
  · exact vertices_piece_9
  · exact vertices_piece_10
  · exact vertices_piece_11
  · exact vertices_piece_12
  · exact vertices_piece_13
  · exact vertices_piece_14
  · exact vertices_piece_15
  · exact vertices_piece_16
  · exact vertices_piece_17
  · exact vertices_piece_18
  · exact vertices_piece_19
  · exact vertices_piece_20
  · exact vertices_piece_21
  · exact vertices_piece_22
  · exact vertices_piece_23
  · exact vertices_piece_24
  · exact vertices_piece_25
  · exact vertices_piece_26
  · exact vertices_piece_27
  · exact vertices_piece_28
  · exact vertices_piece_29
  · exact vertices_piece_30
  · exact vertices_piece_31
  · exact vertices_piece_32
  · exact vertices_piece_33
  · exact vertices_piece_34
  · exact vertices_piece_35
  · exact vertices_piece_36
  · exact vertices_piece_37
  · exact vertices_piece_38
  · exact vertices_piece_39

theorem source_valid : ∀ i, Cayley.Valid (source i) := by
  intro i
  exact Cayley.check_sound _ (allFin_eq_true.mp source_checked i)

theorem gram_checked : orthogonalCheck record.placement = true := gram_checked_all

theorem walls_checked :
    allFin 40 (fun i => allFin 24 (fun p => allFin 0 (fun f =>
      decide (qdot (record.placement.toCertificate.walls f).normal
        (record.placement.toCertificate.vertices i p) ≤
          (record.placement.toCertificate.walls f).offset)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  apply allFin_eq_true.mpr
  intro p
  apply allFin_eq_true.mpr
  intro f
  exact Fin.elim0 f

theorem rational_checked : Rational.check record.placement.toCertificate = true := by
  simp only [Rational.check, Bool.and_eq_true]
  exact ⟨walls_checked, pair_checked⟩

theorem placed_checked : checkPlaced record.placement = true := by
  simp only [checkPlaced, Bool.and_eq_true]
  exact ⟨gram_checked, rational_checked⟩

theorem scale_checked : decide (0 < record.scale) = true := by decide +kernel

theorem checked : Barycentric.check record = true := by
  simp only [Barycentric.check, Bool.and_eq_true]
  exact ⟨⟨placed_checked, scale_checked⟩, vertices_checked⟩

/-- Complete convex-polytope packing, assembled from kernel-checked fragments. -/
theorem packing : Barycentric.Valid record := Barycentric.check_sound record checked

theorem proper_orientation : ∀ i : Fin 40,
    Matrix.det (fun a b => (record.placement.rotation i a b : ℝ)) = 1 := by
  intro i
  exact Cayley.determinant_real (source i) (allFin_eq_true.mp source_checked i)

#print axioms source_valid
#print axioms packing
#print axioms proper_orientation
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
