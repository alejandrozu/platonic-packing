import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex020_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex020_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex020_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_20 :
    allFin 24 (fun p => record.vertexCheck (20 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_20_0
  · exact vertex_20_1
  · exact vertex_20_2
  · exact vertex_20_3
  · exact vertex_20_4
  · exact vertex_20_5
  · exact vertex_20_6
  · exact vertex_20_7
  · exact vertex_20_8
  · exact vertex_20_9
  · exact vertex_20_10
  · exact vertex_20_11
  · exact vertex_20_12
  · exact vertex_20_13
  · exact vertex_20_14
  · exact vertex_20_15
  · exact vertex_20_16
  · exact vertex_20_17
  · exact vertex_20_18
  · exact vertex_20_19
  · exact vertex_20_20
  · exact vertex_20_21
  · exact vertex_20_22
  · exact vertex_20_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_20
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
