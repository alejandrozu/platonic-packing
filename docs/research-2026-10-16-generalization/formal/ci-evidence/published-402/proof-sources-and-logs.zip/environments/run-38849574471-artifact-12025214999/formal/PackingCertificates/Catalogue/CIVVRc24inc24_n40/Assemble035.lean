import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex035_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex035_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex035_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_35 :
    allFin 24 (fun p => record.vertexCheck (35 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_35_0
  · exact vertex_35_1
  · exact vertex_35_2
  · exact vertex_35_3
  · exact vertex_35_4
  · exact vertex_35_5
  · exact vertex_35_6
  · exact vertex_35_7
  · exact vertex_35_8
  · exact vertex_35_9
  · exact vertex_35_10
  · exact vertex_35_11
  · exact vertex_35_12
  · exact vertex_35_13
  · exact vertex_35_14
  · exact vertex_35_15
  · exact vertex_35_16
  · exact vertex_35_17
  · exact vertex_35_18
  · exact vertex_35_19
  · exact vertex_35_20
  · exact vertex_35_21
  · exact vertex_35_22
  · exact vertex_35_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_35
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
