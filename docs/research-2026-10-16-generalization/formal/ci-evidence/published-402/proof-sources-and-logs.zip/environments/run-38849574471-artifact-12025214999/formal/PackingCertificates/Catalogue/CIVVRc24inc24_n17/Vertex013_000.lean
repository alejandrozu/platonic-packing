import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_13_0 :
    record.vertexCheck (13 : Fin 17) (0 : Fin 24) = true := by decide +kernel


theorem vertex_13_1 :
    record.vertexCheck (13 : Fin 17) (1 : Fin 24) = true := by decide +kernel


theorem vertex_13_2 :
    record.vertexCheck (13 : Fin 17) (2 : Fin 24) = true := by decide +kernel


theorem vertex_13_3 :
    record.vertexCheck (13 : Fin 17) (3 : Fin 24) = true := by decide +kernel


theorem vertex_13_4 :
    record.vertexCheck (13 : Fin 17) (4 : Fin 24) = true := by decide +kernel


theorem vertex_13_5 :
    record.vertexCheck (13 : Fin 17) (5 : Fin 24) = true := by decide +kernel


theorem vertex_13_6 :
    record.vertexCheck (13 : Fin 17) (6 : Fin 24) = true := by decide +kernel


theorem vertex_13_7 :
    record.vertexCheck (13 : Fin 17) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_13_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
