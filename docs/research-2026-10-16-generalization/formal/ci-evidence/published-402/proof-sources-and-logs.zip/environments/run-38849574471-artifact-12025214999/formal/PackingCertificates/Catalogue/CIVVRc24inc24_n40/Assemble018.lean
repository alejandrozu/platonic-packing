import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex018_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex018_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex018_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_18 :
    allFin 24 (fun p => record.vertexCheck (18 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_18_0
  · exact vertex_18_1
  · exact vertex_18_2
  · exact vertex_18_3
  · exact vertex_18_4
  · exact vertex_18_5
  · exact vertex_18_6
  · exact vertex_18_7
  · exact vertex_18_8
  · exact vertex_18_9
  · exact vertex_18_10
  · exact vertex_18_11
  · exact vertex_18_12
  · exact vertex_18_13
  · exact vertex_18_14
  · exact vertex_18_15
  · exact vertex_18_16
  · exact vertex_18_17
  · exact vertex_18_18
  · exact vertex_18_19
  · exact vertex_18_20
  · exact vertex_18_21
  · exact vertex_18_22
  · exact vertex_18_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_18
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
