import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem source_piece_3 : Cayley.check (source (3 : Fin 6)) = true := by decide +kernel

theorem gram_piece_3 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (3 : Fin 6) a)
        (record.placement.rotation (3 : Fin 6) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_3 :
    allFin 6 (fun j => if (3 : Fin 6) < j then
      planeCheck (record.placement.toCertificate.vertices (3 : Fin 6))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (3 : Fin 6) j) else true) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.source_piece_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.gram_piece_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.pair_row_3
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
