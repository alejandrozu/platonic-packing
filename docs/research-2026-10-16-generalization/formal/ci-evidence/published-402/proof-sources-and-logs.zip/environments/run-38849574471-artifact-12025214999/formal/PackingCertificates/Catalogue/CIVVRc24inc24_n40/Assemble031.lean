import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex031_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex031_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex031_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_31 :
    allFin 24 (fun p => record.vertexCheck (31 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_31_0
  · exact vertex_31_1
  · exact vertex_31_2
  · exact vertex_31_3
  · exact vertex_31_4
  · exact vertex_31_5
  · exact vertex_31_6
  · exact vertex_31_7
  · exact vertex_31_8
  · exact vertex_31_9
  · exact vertex_31_10
  · exact vertex_31_11
  · exact vertex_31_12
  · exact vertex_31_13
  · exact vertex_31_14
  · exact vertex_31_15
  · exact vertex_31_16
  · exact vertex_31_17
  · exact vertex_31_18
  · exact vertex_31_19
  · exact vertex_31_20
  · exact vertex_31_21
  · exact vertex_31_22
  · exact vertex_31_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_31
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
