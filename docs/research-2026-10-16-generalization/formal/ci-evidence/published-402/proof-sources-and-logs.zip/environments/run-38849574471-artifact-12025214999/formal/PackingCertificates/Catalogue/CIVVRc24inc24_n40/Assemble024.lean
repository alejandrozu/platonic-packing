import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex024_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex024_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex024_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_24 :
    allFin 24 (fun p => record.vertexCheck (24 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_24_0
  · exact vertex_24_1
  · exact vertex_24_2
  · exact vertex_24_3
  · exact vertex_24_4
  · exact vertex_24_5
  · exact vertex_24_6
  · exact vertex_24_7
  · exact vertex_24_8
  · exact vertex_24_9
  · exact vertex_24_10
  · exact vertex_24_11
  · exact vertex_24_12
  · exact vertex_24_13
  · exact vertex_24_14
  · exact vertex_24_15
  · exact vertex_24_16
  · exact vertex_24_17
  · exact vertex_24_18
  · exact vertex_24_19
  · exact vertex_24_20
  · exact vertex_24_21
  · exact vertex_24_22
  · exact vertex_24_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_24
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
