import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n05
open PackingCertificates.Rational

theorem vertex_4_8 :
    record.vertexCheck (4 : Fin 5) (8 : Fin 24) = true := by decide +kernel


theorem vertex_4_9 :
    record.vertexCheck (4 : Fin 5) (9 : Fin 24) = true := by decide +kernel


theorem vertex_4_10 :
    record.vertexCheck (4 : Fin 5) (10 : Fin 24) = true := by decide +kernel


theorem vertex_4_11 :
    record.vertexCheck (4 : Fin 5) (11 : Fin 24) = true := by decide +kernel


theorem vertex_4_12 :
    record.vertexCheck (4 : Fin 5) (12 : Fin 24) = true := by decide +kernel


theorem vertex_4_13 :
    record.vertexCheck (4 : Fin 5) (13 : Fin 24) = true := by decide +kernel


theorem vertex_4_14 :
    record.vertexCheck (4 : Fin 5) (14 : Fin 24) = true := by decide +kernel


theorem vertex_4_15 :
    record.vertexCheck (4 : Fin 5) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertex_4_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n05
