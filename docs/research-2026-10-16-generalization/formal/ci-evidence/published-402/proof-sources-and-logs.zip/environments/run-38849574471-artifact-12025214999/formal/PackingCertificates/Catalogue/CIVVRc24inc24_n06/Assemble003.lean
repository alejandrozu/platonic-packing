import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex003_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex003_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Vertex003_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem vertices_piece_3 :
    allFin 24 (fun p => record.vertexCheck (3 : Fin 6) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_3_0
  · exact vertex_3_1
  · exact vertex_3_2
  · exact vertex_3_3
  · exact vertex_3_4
  · exact vertex_3_5
  · exact vertex_3_6
  · exact vertex_3_7
  · exact vertex_3_8
  · exact vertex_3_9
  · exact vertex_3_10
  · exact vertex_3_11
  · exact vertex_3_12
  · exact vertex_3_13
  · exact vertex_3_14
  · exact vertex_3_15
  · exact vertex_3_16
  · exact vertex_3_17
  · exact vertex_3_18
  · exact vertex_3_19
  · exact vertex_3_20
  · exact vertex_3_21
  · exact vertex_3_22
  · exact vertex_3_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertices_piece_3
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
