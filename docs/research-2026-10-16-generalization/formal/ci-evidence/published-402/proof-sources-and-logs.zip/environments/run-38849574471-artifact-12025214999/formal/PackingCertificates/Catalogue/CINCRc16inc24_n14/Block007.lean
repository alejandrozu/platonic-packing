import PackingCertificates.Catalogue.CINCRc16inc24_n14.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CINCRc16inc24_n14
open PackingCertificates.Rational

theorem source_piece_7 : Cayley.check (source (7 : Fin 14)) = true := by decide +kernel

theorem gram_piece_7 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (7 : Fin 14) a)
        (record.placement.rotation (7 : Fin 14) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_7 :
    allFin 14 (fun j => if (7 : Fin 14) < j then
      planeCheck (record.placement.toCertificate.vertices (7 : Fin 14))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (7 : Fin 14) j) else true) = true := by decide +kernel

theorem vertex_7_0 :
    record.vertexCheck (7 : Fin 14) (0 : Fin 8) = true := by decide +kernel

theorem vertex_7_1 :
    record.vertexCheck (7 : Fin 14) (1 : Fin 8) = true := by decide +kernel

theorem vertex_7_2 :
    record.vertexCheck (7 : Fin 14) (2 : Fin 8) = true := by decide +kernel

theorem vertex_7_3 :
    record.vertexCheck (7 : Fin 14) (3 : Fin 8) = true := by decide +kernel

theorem vertex_7_4 :
    record.vertexCheck (7 : Fin 14) (4 : Fin 8) = true := by decide +kernel

theorem vertex_7_5 :
    record.vertexCheck (7 : Fin 14) (5 : Fin 8) = true := by decide +kernel

theorem vertex_7_6 :
    record.vertexCheck (7 : Fin 14) (6 : Fin 8) = true := by decide +kernel

theorem vertex_7_7 :
    record.vertexCheck (7 : Fin 14) (7 : Fin 8) = true := by decide +kernel

theorem vertices_piece_7 :
    allFin 8 (fun p => record.vertexCheck (7 : Fin 14) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_7_0
  · exact vertex_7_1
  · exact vertex_7_2
  · exact vertex_7_3
  · exact vertex_7_4
  · exact vertex_7_5
  · exact vertex_7_6
  · exact vertex_7_7


#print axioms source_piece_7
#print axioms gram_piece_7
#print axioms pair_row_7
#print axioms vertices_piece_7
end PackingCertificates.Catalogue.CINCRc16inc24_n14
