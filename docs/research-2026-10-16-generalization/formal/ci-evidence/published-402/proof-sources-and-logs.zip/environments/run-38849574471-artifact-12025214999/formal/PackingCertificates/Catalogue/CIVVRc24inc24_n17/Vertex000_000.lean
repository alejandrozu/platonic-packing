import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_0_0 :
    record.vertexCheck (0 : Fin 17) (0 : Fin 24) = true := by decide +kernel


theorem vertex_0_1 :
    record.vertexCheck (0 : Fin 17) (1 : Fin 24) = true := by decide +kernel


theorem vertex_0_2 :
    record.vertexCheck (0 : Fin 17) (2 : Fin 24) = true := by decide +kernel


theorem vertex_0_3 :
    record.vertexCheck (0 : Fin 17) (3 : Fin 24) = true := by decide +kernel


theorem vertex_0_4 :
    record.vertexCheck (0 : Fin 17) (4 : Fin 24) = true := by decide +kernel


theorem vertex_0_5 :
    record.vertexCheck (0 : Fin 17) (5 : Fin 24) = true := by decide +kernel


theorem vertex_0_6 :
    record.vertexCheck (0 : Fin 17) (6 : Fin 24) = true := by decide +kernel


theorem vertex_0_7 :
    record.vertexCheck (0 : Fin 17) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_0_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
