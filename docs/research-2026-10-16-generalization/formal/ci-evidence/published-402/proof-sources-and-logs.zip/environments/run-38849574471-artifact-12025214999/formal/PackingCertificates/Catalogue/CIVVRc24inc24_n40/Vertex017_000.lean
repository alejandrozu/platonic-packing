import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_17_0 :
    record.vertexCheck (17 : Fin 40) (0 : Fin 24) = true := by decide +kernel


theorem vertex_17_1 :
    record.vertexCheck (17 : Fin 40) (1 : Fin 24) = true := by decide +kernel


theorem vertex_17_2 :
    record.vertexCheck (17 : Fin 40) (2 : Fin 24) = true := by decide +kernel


theorem vertex_17_3 :
    record.vertexCheck (17 : Fin 40) (3 : Fin 24) = true := by decide +kernel


theorem vertex_17_4 :
    record.vertexCheck (17 : Fin 40) (4 : Fin 24) = true := by decide +kernel


theorem vertex_17_5 :
    record.vertexCheck (17 : Fin 40) (5 : Fin 24) = true := by decide +kernel


theorem vertex_17_6 :
    record.vertexCheck (17 : Fin 40) (6 : Fin 24) = true := by decide +kernel


theorem vertex_17_7 :
    record.vertexCheck (17 : Fin 40) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_17_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
