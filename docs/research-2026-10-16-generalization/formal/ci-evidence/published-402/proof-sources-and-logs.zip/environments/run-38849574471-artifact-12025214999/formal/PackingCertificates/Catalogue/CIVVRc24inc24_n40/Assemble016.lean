import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex016_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex016_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex016_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_16 :
    allFin 24 (fun p => record.vertexCheck (16 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_16_0
  · exact vertex_16_1
  · exact vertex_16_2
  · exact vertex_16_3
  · exact vertex_16_4
  · exact vertex_16_5
  · exact vertex_16_6
  · exact vertex_16_7
  · exact vertex_16_8
  · exact vertex_16_9
  · exact vertex_16_10
  · exact vertex_16_11
  · exact vertex_16_12
  · exact vertex_16_13
  · exact vertex_16_14
  · exact vertex_16_15
  · exact vertex_16_16
  · exact vertex_16_17
  · exact vertex_16_18
  · exact vertex_16_19
  · exact vertex_16_20
  · exact vertex_16_21
  · exact vertex_16_22
  · exact vertex_16_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_16
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
