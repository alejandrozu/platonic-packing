import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem vertex_2_0 :
    record.vertexCheck (2 : Fin 6) (0 : Fin 24) = true := by decide +kernel


theorem vertex_2_1 :
    record.vertexCheck (2 : Fin 6) (1 : Fin 24) = true := by decide +kernel


theorem vertex_2_2 :
    record.vertexCheck (2 : Fin 6) (2 : Fin 24) = true := by decide +kernel


theorem vertex_2_3 :
    record.vertexCheck (2 : Fin 6) (3 : Fin 24) = true := by decide +kernel


theorem vertex_2_4 :
    record.vertexCheck (2 : Fin 6) (4 : Fin 24) = true := by decide +kernel


theorem vertex_2_5 :
    record.vertexCheck (2 : Fin 6) (5 : Fin 24) = true := by decide +kernel


theorem vertex_2_6 :
    record.vertexCheck (2 : Fin 6) (6 : Fin 24) = true := by decide +kernel


theorem vertex_2_7 :
    record.vertexCheck (2 : Fin 6) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_2_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
