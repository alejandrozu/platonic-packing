import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem source_piece_28 : Cayley.check (source (28 : Fin 40)) = true := by decide +kernel

theorem gram_piece_28 :
    allFin 4 (fun a => allFin 4 (fun b =>
      decide (qdot (record.placement.rotation (28 : Fin 40) a)
        (record.placement.rotation (28 : Fin 40) b) = if a = b then 1 else 0))) = true := by decide +kernel


theorem pair_row_28 :
    allFin 40 (fun j => if (28 : Fin 40) < j then
      planeCheck (record.placement.toCertificate.vertices (28 : Fin 40))
        (record.placement.toCertificate.vertices j)
        (record.placement.separation (28 : Fin 40) j) else true) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.source_piece_28
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.gram_piece_28
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.pair_row_28
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
