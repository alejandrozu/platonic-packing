import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex008_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex008_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex008_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_8 :
    allFin 24 (fun p => record.vertexCheck (8 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_8_0
  · exact vertex_8_1
  · exact vertex_8_2
  · exact vertex_8_3
  · exact vertex_8_4
  · exact vertex_8_5
  · exact vertex_8_6
  · exact vertex_8_7
  · exact vertex_8_8
  · exact vertex_8_9
  · exact vertex_8_10
  · exact vertex_8_11
  · exact vertex_8_12
  · exact vertex_8_13
  · exact vertex_8_14
  · exact vertex_8_15
  · exact vertex_8_16
  · exact vertex_8_17
  · exact vertex_8_18
  · exact vertex_8_19
  · exact vertex_8_20
  · exact vertex_8_21
  · exact vertex_8_22
  · exact vertex_8_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_8
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
