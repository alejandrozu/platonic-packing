import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_25_16 :
    record.vertexCheck (25 : Fin 40) (16 : Fin 24) = true := by decide +kernel


theorem vertex_25_17 :
    record.vertexCheck (25 : Fin 40) (17 : Fin 24) = true := by decide +kernel


theorem vertex_25_18 :
    record.vertexCheck (25 : Fin 40) (18 : Fin 24) = true := by decide +kernel


theorem vertex_25_19 :
    record.vertexCheck (25 : Fin 40) (19 : Fin 24) = true := by decide +kernel


theorem vertex_25_20 :
    record.vertexCheck (25 : Fin 40) (20 : Fin 24) = true := by decide +kernel


theorem vertex_25_21 :
    record.vertexCheck (25 : Fin 40) (21 : Fin 24) = true := by decide +kernel


theorem vertex_25_22 :
    record.vertexCheck (25 : Fin 40) (22 : Fin 24) = true := by decide +kernel


theorem vertex_25_23 :
    record.vertexCheck (25 : Fin 40) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_25_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
