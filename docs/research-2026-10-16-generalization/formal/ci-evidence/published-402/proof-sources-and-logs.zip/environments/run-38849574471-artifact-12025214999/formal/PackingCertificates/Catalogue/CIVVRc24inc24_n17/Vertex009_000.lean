import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_9_0 :
    record.vertexCheck (9 : Fin 17) (0 : Fin 24) = true := by decide +kernel


theorem vertex_9_1 :
    record.vertexCheck (9 : Fin 17) (1 : Fin 24) = true := by decide +kernel


theorem vertex_9_2 :
    record.vertexCheck (9 : Fin 17) (2 : Fin 24) = true := by decide +kernel


theorem vertex_9_3 :
    record.vertexCheck (9 : Fin 17) (3 : Fin 24) = true := by decide +kernel


theorem vertex_9_4 :
    record.vertexCheck (9 : Fin 17) (4 : Fin 24) = true := by decide +kernel


theorem vertex_9_5 :
    record.vertexCheck (9 : Fin 17) (5 : Fin 24) = true := by decide +kernel


theorem vertex_9_6 :
    record.vertexCheck (9 : Fin 17) (6 : Fin 24) = true := by decide +kernel


theorem vertex_9_7 :
    record.vertexCheck (9 : Fin 17) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_9_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
