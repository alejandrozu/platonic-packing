import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_11_8 :
    record.vertexCheck (11 : Fin 17) (8 : Fin 24) = true := by decide +kernel


theorem vertex_11_9 :
    record.vertexCheck (11 : Fin 17) (9 : Fin 24) = true := by decide +kernel


theorem vertex_11_10 :
    record.vertexCheck (11 : Fin 17) (10 : Fin 24) = true := by decide +kernel


theorem vertex_11_11 :
    record.vertexCheck (11 : Fin 17) (11 : Fin 24) = true := by decide +kernel


theorem vertex_11_12 :
    record.vertexCheck (11 : Fin 17) (12 : Fin 24) = true := by decide +kernel


theorem vertex_11_13 :
    record.vertexCheck (11 : Fin 17) (13 : Fin 24) = true := by decide +kernel


theorem vertex_11_14 :
    record.vertexCheck (11 : Fin 17) (14 : Fin 24) = true := by decide +kernel


theorem vertex_11_15 :
    record.vertexCheck (11 : Fin 17) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_11_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
