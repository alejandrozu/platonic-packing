import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex011_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex011_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex011_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_11 :
    allFin 24 (fun p => record.vertexCheck (11 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_11_0
  · exact vertex_11_1
  · exact vertex_11_2
  · exact vertex_11_3
  · exact vertex_11_4
  · exact vertex_11_5
  · exact vertex_11_6
  · exact vertex_11_7
  · exact vertex_11_8
  · exact vertex_11_9
  · exact vertex_11_10
  · exact vertex_11_11
  · exact vertex_11_12
  · exact vertex_11_13
  · exact vertex_11_14
  · exact vertex_11_15
  · exact vertex_11_16
  · exact vertex_11_17
  · exact vertex_11_18
  · exact vertex_11_19
  · exact vertex_11_20
  · exact vertex_11_21
  · exact vertex_11_22
  · exact vertex_11_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_11
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
