import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_2_8 :
    record.vertexCheck (2 : Fin 17) (8 : Fin 24) = true := by decide +kernel


theorem vertex_2_9 :
    record.vertexCheck (2 : Fin 17) (9 : Fin 24) = true := by decide +kernel


theorem vertex_2_10 :
    record.vertexCheck (2 : Fin 17) (10 : Fin 24) = true := by decide +kernel


theorem vertex_2_11 :
    record.vertexCheck (2 : Fin 17) (11 : Fin 24) = true := by decide +kernel


theorem vertex_2_12 :
    record.vertexCheck (2 : Fin 17) (12 : Fin 24) = true := by decide +kernel


theorem vertex_2_13 :
    record.vertexCheck (2 : Fin 17) (13 : Fin 24) = true := by decide +kernel


theorem vertex_2_14 :
    record.vertexCheck (2 : Fin 17) (14 : Fin 24) = true := by decide +kernel


theorem vertex_2_15 :
    record.vertexCheck (2 : Fin 17) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_2_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
