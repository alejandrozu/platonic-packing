import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex030_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex030_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex030_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_30 :
    allFin 24 (fun p => record.vertexCheck (30 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_30_0
  · exact vertex_30_1
  · exact vertex_30_2
  · exact vertex_30_3
  · exact vertex_30_4
  · exact vertex_30_5
  · exact vertex_30_6
  · exact vertex_30_7
  · exact vertex_30_8
  · exact vertex_30_9
  · exact vertex_30_10
  · exact vertex_30_11
  · exact vertex_30_12
  · exact vertex_30_13
  · exact vertex_30_14
  · exact vertex_30_15
  · exact vertex_30_16
  · exact vertex_30_17
  · exact vertex_30_18
  · exact vertex_30_19
  · exact vertex_30_20
  · exact vertex_30_21
  · exact vertex_30_22
  · exact vertex_30_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_30
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
