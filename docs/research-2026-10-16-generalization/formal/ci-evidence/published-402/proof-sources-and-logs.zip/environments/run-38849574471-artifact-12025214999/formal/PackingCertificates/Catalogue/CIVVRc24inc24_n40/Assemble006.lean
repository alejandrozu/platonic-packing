import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex006_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex006_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex006_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_6 :
    allFin 24 (fun p => record.vertexCheck (6 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_6_0
  · exact vertex_6_1
  · exact vertex_6_2
  · exact vertex_6_3
  · exact vertex_6_4
  · exact vertex_6_5
  · exact vertex_6_6
  · exact vertex_6_7
  · exact vertex_6_8
  · exact vertex_6_9
  · exact vertex_6_10
  · exact vertex_6_11
  · exact vertex_6_12
  · exact vertex_6_13
  · exact vertex_6_14
  · exact vertex_6_15
  · exact vertex_6_16
  · exact vertex_6_17
  · exact vertex_6_18
  · exact vertex_6_19
  · exact vertex_6_20
  · exact vertex_6_21
  · exact vertex_6_22
  · exact vertex_6_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_6
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
