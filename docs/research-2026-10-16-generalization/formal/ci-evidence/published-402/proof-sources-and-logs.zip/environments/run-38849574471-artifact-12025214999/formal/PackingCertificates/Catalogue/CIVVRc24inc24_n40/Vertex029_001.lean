import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_29_8 :
    record.vertexCheck (29 : Fin 40) (8 : Fin 24) = true := by decide +kernel


theorem vertex_29_9 :
    record.vertexCheck (29 : Fin 40) (9 : Fin 24) = true := by decide +kernel


theorem vertex_29_10 :
    record.vertexCheck (29 : Fin 40) (10 : Fin 24) = true := by decide +kernel


theorem vertex_29_11 :
    record.vertexCheck (29 : Fin 40) (11 : Fin 24) = true := by decide +kernel


theorem vertex_29_12 :
    record.vertexCheck (29 : Fin 40) (12 : Fin 24) = true := by decide +kernel


theorem vertex_29_13 :
    record.vertexCheck (29 : Fin 40) (13 : Fin 24) = true := by decide +kernel


theorem vertex_29_14 :
    record.vertexCheck (29 : Fin 40) (14 : Fin 24) = true := by decide +kernel


theorem vertex_29_15 :
    record.vertexCheck (29 : Fin 40) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_29_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
