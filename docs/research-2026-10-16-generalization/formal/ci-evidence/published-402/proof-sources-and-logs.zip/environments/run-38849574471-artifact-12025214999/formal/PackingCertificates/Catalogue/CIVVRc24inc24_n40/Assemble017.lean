import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex017_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex017_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex017_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_17 :
    allFin 24 (fun p => record.vertexCheck (17 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_17_0
  · exact vertex_17_1
  · exact vertex_17_2
  · exact vertex_17_3
  · exact vertex_17_4
  · exact vertex_17_5
  · exact vertex_17_6
  · exact vertex_17_7
  · exact vertex_17_8
  · exact vertex_17_9
  · exact vertex_17_10
  · exact vertex_17_11
  · exact vertex_17_12
  · exact vertex_17_13
  · exact vertex_17_14
  · exact vertex_17_15
  · exact vertex_17_16
  · exact vertex_17_17
  · exact vertex_17_18
  · exact vertex_17_19
  · exact vertex_17_20
  · exact vertex_17_21
  · exact vertex_17_22
  · exact vertex_17_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_17
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
