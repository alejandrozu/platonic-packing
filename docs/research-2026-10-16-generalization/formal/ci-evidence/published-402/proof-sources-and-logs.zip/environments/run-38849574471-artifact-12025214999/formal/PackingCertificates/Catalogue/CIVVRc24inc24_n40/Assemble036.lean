import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex036_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex036_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex036_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_36 :
    allFin 24 (fun p => record.vertexCheck (36 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_36_0
  · exact vertex_36_1
  · exact vertex_36_2
  · exact vertex_36_3
  · exact vertex_36_4
  · exact vertex_36_5
  · exact vertex_36_6
  · exact vertex_36_7
  · exact vertex_36_8
  · exact vertex_36_9
  · exact vertex_36_10
  · exact vertex_36_11
  · exact vertex_36_12
  · exact vertex_36_13
  · exact vertex_36_14
  · exact vertex_36_15
  · exact vertex_36_16
  · exact vertex_36_17
  · exact vertex_36_18
  · exact vertex_36_19
  · exact vertex_36_20
  · exact vertex_36_21
  · exact vertex_36_22
  · exact vertex_36_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_36
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
