import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex009_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex009_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex009_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_9 :
    allFin 24 (fun p => record.vertexCheck (9 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_9_0
  · exact vertex_9_1
  · exact vertex_9_2
  · exact vertex_9_3
  · exact vertex_9_4
  · exact vertex_9_5
  · exact vertex_9_6
  · exact vertex_9_7
  · exact vertex_9_8
  · exact vertex_9_9
  · exact vertex_9_10
  · exact vertex_9_11
  · exact vertex_9_12
  · exact vertex_9_13
  · exact vertex_9_14
  · exact vertex_9_15
  · exact vertex_9_16
  · exact vertex_9_17
  · exact vertex_9_18
  · exact vertex_9_19
  · exact vertex_9_20
  · exact vertex_9_21
  · exact vertex_9_22
  · exact vertex_9_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_9
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
