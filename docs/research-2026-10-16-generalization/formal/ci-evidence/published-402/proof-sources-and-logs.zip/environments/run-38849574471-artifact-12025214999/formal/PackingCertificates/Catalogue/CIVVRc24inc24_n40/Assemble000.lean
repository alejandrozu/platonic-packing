import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex000_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex000_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex000_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_0 :
    allFin 24 (fun p => record.vertexCheck (0 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_0_0
  · exact vertex_0_1
  · exact vertex_0_2
  · exact vertex_0_3
  · exact vertex_0_4
  · exact vertex_0_5
  · exact vertex_0_6
  · exact vertex_0_7
  · exact vertex_0_8
  · exact vertex_0_9
  · exact vertex_0_10
  · exact vertex_0_11
  · exact vertex_0_12
  · exact vertex_0_13
  · exact vertex_0_14
  · exact vertex_0_15
  · exact vertex_0_16
  · exact vertex_0_17
  · exact vertex_0_18
  · exact vertex_0_19
  · exact vertex_0_20
  · exact vertex_0_21
  · exact vertex_0_22
  · exact vertex_0_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_0
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
