import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex023_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex023_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex023_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_23 :
    allFin 24 (fun p => record.vertexCheck (23 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_23_0
  · exact vertex_23_1
  · exact vertex_23_2
  · exact vertex_23_3
  · exact vertex_23_4
  · exact vertex_23_5
  · exact vertex_23_6
  · exact vertex_23_7
  · exact vertex_23_8
  · exact vertex_23_9
  · exact vertex_23_10
  · exact vertex_23_11
  · exact vertex_23_12
  · exact vertex_23_13
  · exact vertex_23_14
  · exact vertex_23_15
  · exact vertex_23_16
  · exact vertex_23_17
  · exact vertex_23_18
  · exact vertex_23_19
  · exact vertex_23_20
  · exact vertex_23_21
  · exact vertex_23_22
  · exact vertex_23_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
