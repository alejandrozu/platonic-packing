import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Vertex004_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Vertex004_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n05.Vertex004_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n05
open PackingCertificates.Rational

theorem vertices_piece_4 :
    allFin 24 (fun p => record.vertexCheck (4 : Fin 5) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_4_0
  · exact vertex_4_1
  · exact vertex_4_2
  · exact vertex_4_3
  · exact vertex_4_4
  · exact vertex_4_5
  · exact vertex_4_6
  · exact vertex_4_7
  · exact vertex_4_8
  · exact vertex_4_9
  · exact vertex_4_10
  · exact vertex_4_11
  · exact vertex_4_12
  · exact vertex_4_13
  · exact vertex_4_14
  · exact vertex_4_15
  · exact vertex_4_16
  · exact vertex_4_17
  · exact vertex_4_18
  · exact vertex_4_19
  · exact vertex_4_20
  · exact vertex_4_21
  · exact vertex_4_22
  · exact vertex_4_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n05.vertices_piece_4
end PackingCertificates.Catalogue.CIVVRc24inc24_n05
