import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source002
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble002
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source003
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble003
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source004
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble004
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source005
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble005
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source006
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble006
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source007
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble007
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source008
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble008
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source009
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble009
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source010
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble010
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source011
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble011
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source012
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble012
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source013
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble013
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source014
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble014
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source015
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble015
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Source016
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Assemble016

-- Original source: records/c24inc24/c24inc24_n17.json
-- Original JSON SHA256: 65fd4b3656f8fe8e78db78a991da0d8838559bd08aa446314cc608e334ac7d83
-- Canonical geometry SHA256: 668f2e176e56e11738722784a6286784151479f24820db13910bd627627b596e
-- Record identifier: c24inc24_n17
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem source_checked : allFin 17 (fun i => Cayley.check (source i)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact source_piece_0
  · exact source_piece_1
  · exact source_piece_2
  · exact source_piece_3
  · exact source_piece_4
  · exact source_piece_5
  · exact source_piece_6
  · exact source_piece_7
  · exact source_piece_8
  · exact source_piece_9
  · exact source_piece_10
  · exact source_piece_11
  · exact source_piece_12
  · exact source_piece_13
  · exact source_piece_14
  · exact source_piece_15
  · exact source_piece_16

theorem gram_checked_all : allFin 17 (fun i => allFin 4 (fun a => allFin 4 (fun b => decide (qdot (record.placement.rotation i a) (record.placement.rotation i b) = if a = b then 1 else 0)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact gram_piece_0
  · exact gram_piece_1
  · exact gram_piece_2
  · exact gram_piece_3
  · exact gram_piece_4
  · exact gram_piece_5
  · exact gram_piece_6
  · exact gram_piece_7
  · exact gram_piece_8
  · exact gram_piece_9
  · exact gram_piece_10
  · exact gram_piece_11
  · exact gram_piece_12
  · exact gram_piece_13
  · exact gram_piece_14
  · exact gram_piece_15
  · exact gram_piece_16

theorem pair_checked : allFin 17 (fun i => allFin 17 (fun j => if i < j then planeCheck (record.placement.toCertificate.vertices i) (record.placement.toCertificate.vertices j) (record.placement.separation i j) else true)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact pair_row_0
  · exact pair_row_1
  · exact pair_row_2
  · exact pair_row_3
  · exact pair_row_4
  · exact pair_row_5
  · exact pair_row_6
  · exact pair_row_7
  · exact pair_row_8
  · exact pair_row_9
  · exact pair_row_10
  · exact pair_row_11
  · exact pair_row_12
  · exact pair_row_13
  · exact pair_row_14
  · exact pair_row_15
  · exact pair_row_16

theorem vertices_checked : allFin 17 (fun i => allFin 24 (fun p => record.vertexCheck i p)) = true := by
  apply allFin_eq_true.mpr
  intro i
  fin_cases i
  · exact vertices_piece_0
  · exact vertices_piece_1
  · exact vertices_piece_2
  · exact vertices_piece_3
  · exact vertices_piece_4
  · exact vertices_piece_5
  · exact vertices_piece_6
  · exact vertices_piece_7
  · exact vertices_piece_8
  · exact vertices_piece_9
  · exact vertices_piece_10
  · exact vertices_piece_11
  · exact vertices_piece_12
  · exact vertices_piece_13
  · exact vertices_piece_14
  · exact vertices_piece_15
  · exact vertices_piece_16

theorem source_valid : ∀ i, Cayley.Valid (source i) := by
  intro i
  exact Cayley.check_sound _ (allFin_eq_true.mp source_checked i)

theorem gram_checked : orthogonalCheck record.placement = true := gram_checked_all

theorem walls_checked :
    allFin 17 (fun i => allFin 24 (fun p => allFin 0 (fun f =>
      decide (qdot (record.placement.toCertificate.walls f).normal
        (record.placement.toCertificate.vertices i p) ≤
          (record.placement.toCertificate.walls f).offset)))) = true := by
  apply allFin_eq_true.mpr
  intro i
  apply allFin_eq_true.mpr
  intro p
  apply allFin_eq_true.mpr
  intro f
  exact Fin.elim0 f

theorem rational_checked : Rational.check record.placement.toCertificate = true := by
  simp only [Rational.check, Bool.and_eq_true]
  exact ⟨walls_checked, pair_checked⟩

theorem placed_checked : checkPlaced record.placement = true := by
  simp only [checkPlaced, Bool.and_eq_true]
  exact ⟨gram_checked, rational_checked⟩

theorem scale_checked : decide (0 < record.scale) = true := by decide +kernel

theorem checked : Barycentric.check record = true := by
  simp only [Barycentric.check, Bool.and_eq_true]
  exact ⟨⟨placed_checked, scale_checked⟩, vertices_checked⟩

/-- Complete convex-polytope packing, assembled from kernel-checked fragments. -/
theorem packing : Barycentric.Valid record := Barycentric.check_sound record checked

theorem proper_orientation : ∀ i : Fin 17,
    Matrix.det (fun a b => (record.placement.rotation i a b : ℝ)) = 1 := by
  intro i
  exact Cayley.determinant_real (source i) (allFin_eq_true.mp source_checked i)

#print axioms source_valid
#print axioms packing
#print axioms proper_orientation
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
