import PackingCertificates.Catalogue.CIVVRc24inc24_n06.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n06
open PackingCertificates.Rational

theorem vertex_1_16 :
    record.vertexCheck (1 : Fin 6) (16 : Fin 24) = true := by decide +kernel


theorem vertex_1_17 :
    record.vertexCheck (1 : Fin 6) (17 : Fin 24) = true := by decide +kernel


theorem vertex_1_18 :
    record.vertexCheck (1 : Fin 6) (18 : Fin 24) = true := by decide +kernel


theorem vertex_1_19 :
    record.vertexCheck (1 : Fin 6) (19 : Fin 24) = true := by decide +kernel


theorem vertex_1_20 :
    record.vertexCheck (1 : Fin 6) (20 : Fin 24) = true := by decide +kernel


theorem vertex_1_21 :
    record.vertexCheck (1 : Fin 6) (21 : Fin 24) = true := by decide +kernel


theorem vertex_1_22 :
    record.vertexCheck (1 : Fin 6) (22 : Fin 24) = true := by decide +kernel


theorem vertex_1_23 :
    record.vertexCheck (1 : Fin 6) (23 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_16
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_17
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_18
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_19
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_20
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_21
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_22
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n06.vertex_1_23
end PackingCertificates.Catalogue.CIVVRc24inc24_n06
