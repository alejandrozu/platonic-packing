import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex032_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex032_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex032_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_32 :
    allFin 24 (fun p => record.vertexCheck (32 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_32_0
  · exact vertex_32_1
  · exact vertex_32_2
  · exact vertex_32_3
  · exact vertex_32_4
  · exact vertex_32_5
  · exact vertex_32_6
  · exact vertex_32_7
  · exact vertex_32_8
  · exact vertex_32_9
  · exact vertex_32_10
  · exact vertex_32_11
  · exact vertex_32_12
  · exact vertex_32_13
  · exact vertex_32_14
  · exact vertex_32_15
  · exact vertex_32_16
  · exact vertex_32_17
  · exact vertex_32_18
  · exact vertex_32_19
  · exact vertex_32_20
  · exact vertex_32_21
  · exact vertex_32_22
  · exact vertex_32_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_32
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
