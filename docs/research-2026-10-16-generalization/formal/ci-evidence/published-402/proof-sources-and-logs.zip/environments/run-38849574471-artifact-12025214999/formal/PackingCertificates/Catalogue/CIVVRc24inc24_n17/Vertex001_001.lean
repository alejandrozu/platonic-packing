import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_1_8 :
    record.vertexCheck (1 : Fin 17) (8 : Fin 24) = true := by decide +kernel


theorem vertex_1_9 :
    record.vertexCheck (1 : Fin 17) (9 : Fin 24) = true := by decide +kernel


theorem vertex_1_10 :
    record.vertexCheck (1 : Fin 17) (10 : Fin 24) = true := by decide +kernel


theorem vertex_1_11 :
    record.vertexCheck (1 : Fin 17) (11 : Fin 24) = true := by decide +kernel


theorem vertex_1_12 :
    record.vertexCheck (1 : Fin 17) (12 : Fin 24) = true := by decide +kernel


theorem vertex_1_13 :
    record.vertexCheck (1 : Fin 17) (13 : Fin 24) = true := by decide +kernel


theorem vertex_1_14 :
    record.vertexCheck (1 : Fin 17) (14 : Fin 24) = true := by decide +kernel


theorem vertex_1_15 :
    record.vertexCheck (1 : Fin 17) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_1_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
