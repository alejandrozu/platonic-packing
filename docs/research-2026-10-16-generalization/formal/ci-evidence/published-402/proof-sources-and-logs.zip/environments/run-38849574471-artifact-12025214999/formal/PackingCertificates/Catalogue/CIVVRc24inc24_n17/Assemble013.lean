import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex013_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex013_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex013_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertices_piece_13 :
    allFin 24 (fun p => record.vertexCheck (13 : Fin 17) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_13_0
  · exact vertex_13_1
  · exact vertex_13_2
  · exact vertex_13_3
  · exact vertex_13_4
  · exact vertex_13_5
  · exact vertex_13_6
  · exact vertex_13_7
  · exact vertex_13_8
  · exact vertex_13_9
  · exact vertex_13_10
  · exact vertex_13_11
  · exact vertex_13_12
  · exact vertex_13_13
  · exact vertex_13_14
  · exact vertex_13_15
  · exact vertex_13_16
  · exact vertex_13_17
  · exact vertex_13_18
  · exact vertex_13_19
  · exact vertex_13_20
  · exact vertex_13_21
  · exact vertex_13_22
  · exact vertex_13_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertices_piece_13
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
