import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex021_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex021_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex021_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_21 :
    allFin 24 (fun p => record.vertexCheck (21 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_21_0
  · exact vertex_21_1
  · exact vertex_21_2
  · exact vertex_21_3
  · exact vertex_21_4
  · exact vertex_21_5
  · exact vertex_21_6
  · exact vertex_21_7
  · exact vertex_21_8
  · exact vertex_21_9
  · exact vertex_21_10
  · exact vertex_21_11
  · exact vertex_21_12
  · exact vertex_21_13
  · exact vertex_21_14
  · exact vertex_21_15
  · exact vertex_21_16
  · exact vertex_21_17
  · exact vertex_21_18
  · exact vertex_21_19
  · exact vertex_21_20
  · exact vertex_21_21
  · exact vertex_21_22
  · exact vertex_21_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_21
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
