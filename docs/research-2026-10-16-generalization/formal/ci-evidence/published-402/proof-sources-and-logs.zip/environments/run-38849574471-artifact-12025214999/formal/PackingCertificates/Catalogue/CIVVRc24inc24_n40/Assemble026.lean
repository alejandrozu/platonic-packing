import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex026_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex026_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex026_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_26 :
    allFin 24 (fun p => record.vertexCheck (26 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_26_0
  · exact vertex_26_1
  · exact vertex_26_2
  · exact vertex_26_3
  · exact vertex_26_4
  · exact vertex_26_5
  · exact vertex_26_6
  · exact vertex_26_7
  · exact vertex_26_8
  · exact vertex_26_9
  · exact vertex_26_10
  · exact vertex_26_11
  · exact vertex_26_12
  · exact vertex_26_13
  · exact vertex_26_14
  · exact vertex_26_15
  · exact vertex_26_16
  · exact vertex_26_17
  · exact vertex_26_18
  · exact vertex_26_19
  · exact vertex_26_20
  · exact vertex_26_21
  · exact vertex_26_22
  · exact vertex_26_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_26
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
