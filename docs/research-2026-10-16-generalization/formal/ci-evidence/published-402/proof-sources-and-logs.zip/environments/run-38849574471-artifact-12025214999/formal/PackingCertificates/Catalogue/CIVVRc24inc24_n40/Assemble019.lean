import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex019_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex019_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex019_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_19 :
    allFin 24 (fun p => record.vertexCheck (19 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_19_0
  · exact vertex_19_1
  · exact vertex_19_2
  · exact vertex_19_3
  · exact vertex_19_4
  · exact vertex_19_5
  · exact vertex_19_6
  · exact vertex_19_7
  · exact vertex_19_8
  · exact vertex_19_9
  · exact vertex_19_10
  · exact vertex_19_11
  · exact vertex_19_12
  · exact vertex_19_13
  · exact vertex_19_14
  · exact vertex_19_15
  · exact vertex_19_16
  · exact vertex_19_17
  · exact vertex_19_18
  · exact vertex_19_19
  · exact vertex_19_20
  · exact vertex_19_21
  · exact vertex_19_22
  · exact vertex_19_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_19
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
