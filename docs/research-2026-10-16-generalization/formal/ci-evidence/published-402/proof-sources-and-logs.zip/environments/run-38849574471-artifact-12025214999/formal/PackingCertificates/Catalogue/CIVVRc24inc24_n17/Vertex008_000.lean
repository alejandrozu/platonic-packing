import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_8_0 :
    record.vertexCheck (8 : Fin 17) (0 : Fin 24) = true := by decide +kernel


theorem vertex_8_1 :
    record.vertexCheck (8 : Fin 17) (1 : Fin 24) = true := by decide +kernel


theorem vertex_8_2 :
    record.vertexCheck (8 : Fin 17) (2 : Fin 24) = true := by decide +kernel


theorem vertex_8_3 :
    record.vertexCheck (8 : Fin 17) (3 : Fin 24) = true := by decide +kernel


theorem vertex_8_4 :
    record.vertexCheck (8 : Fin 17) (4 : Fin 24) = true := by decide +kernel


theorem vertex_8_5 :
    record.vertexCheck (8 : Fin 17) (5 : Fin 24) = true := by decide +kernel


theorem vertex_8_6 :
    record.vertexCheck (8 : Fin 17) (6 : Fin 24) = true := by decide +kernel


theorem vertex_8_7 :
    record.vertexCheck (8 : Fin 17) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_8_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
