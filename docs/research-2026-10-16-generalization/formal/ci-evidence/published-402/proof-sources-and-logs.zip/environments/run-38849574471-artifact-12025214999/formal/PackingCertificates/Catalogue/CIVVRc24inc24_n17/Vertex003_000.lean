import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertex_3_0 :
    record.vertexCheck (3 : Fin 17) (0 : Fin 24) = true := by decide +kernel


theorem vertex_3_1 :
    record.vertexCheck (3 : Fin 17) (1 : Fin 24) = true := by decide +kernel


theorem vertex_3_2 :
    record.vertexCheck (3 : Fin 17) (2 : Fin 24) = true := by decide +kernel


theorem vertex_3_3 :
    record.vertexCheck (3 : Fin 17) (3 : Fin 24) = true := by decide +kernel


theorem vertex_3_4 :
    record.vertexCheck (3 : Fin 17) (4 : Fin 24) = true := by decide +kernel


theorem vertex_3_5 :
    record.vertexCheck (3 : Fin 17) (5 : Fin 24) = true := by decide +kernel


theorem vertex_3_6 :
    record.vertexCheck (3 : Fin 17) (6 : Fin 24) = true := by decide +kernel


theorem vertex_3_7 :
    record.vertexCheck (3 : Fin 17) (7 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_0
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_1
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_2
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_3
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_4
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_5
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_6
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertex_3_7
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
