import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex033_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex033_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex033_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_33 :
    allFin 24 (fun p => record.vertexCheck (33 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_33_0
  · exact vertex_33_1
  · exact vertex_33_2
  · exact vertex_33_3
  · exact vertex_33_4
  · exact vertex_33_5
  · exact vertex_33_6
  · exact vertex_33_7
  · exact vertex_33_8
  · exact vertex_33_9
  · exact vertex_33_10
  · exact vertex_33_11
  · exact vertex_33_12
  · exact vertex_33_13
  · exact vertex_33_14
  · exact vertex_33_15
  · exact vertex_33_16
  · exact vertex_33_17
  · exact vertex_33_18
  · exact vertex_33_19
  · exact vertex_33_20
  · exact vertex_33_21
  · exact vertex_33_22
  · exact vertex_33_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_33
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
