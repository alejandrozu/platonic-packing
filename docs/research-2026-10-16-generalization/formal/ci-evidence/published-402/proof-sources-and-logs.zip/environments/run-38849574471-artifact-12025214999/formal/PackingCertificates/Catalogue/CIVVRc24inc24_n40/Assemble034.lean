import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex034_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex034_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex034_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_34 :
    allFin 24 (fun p => record.vertexCheck (34 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_34_0
  · exact vertex_34_1
  · exact vertex_34_2
  · exact vertex_34_3
  · exact vertex_34_4
  · exact vertex_34_5
  · exact vertex_34_6
  · exact vertex_34_7
  · exact vertex_34_8
  · exact vertex_34_9
  · exact vertex_34_10
  · exact vertex_34_11
  · exact vertex_34_12
  · exact vertex_34_13
  · exact vertex_34_14
  · exact vertex_34_15
  · exact vertex_34_16
  · exact vertex_34_17
  · exact vertex_34_18
  · exact vertex_34_19
  · exact vertex_34_20
  · exact vertex_34_21
  · exact vertex_34_22
  · exact vertex_34_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_34
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
