import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex038_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex038_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex038_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_38 :
    allFin 24 (fun p => record.vertexCheck (38 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_38_0
  · exact vertex_38_1
  · exact vertex_38_2
  · exact vertex_38_3
  · exact vertex_38_4
  · exact vertex_38_5
  · exact vertex_38_6
  · exact vertex_38_7
  · exact vertex_38_8
  · exact vertex_38_9
  · exact vertex_38_10
  · exact vertex_38_11
  · exact vertex_38_12
  · exact vertex_38_13
  · exact vertex_38_14
  · exact vertex_38_15
  · exact vertex_38_16
  · exact vertex_38_17
  · exact vertex_38_18
  · exact vertex_38_19
  · exact vertex_38_20
  · exact vertex_38_21
  · exact vertex_38_22
  · exact vertex_38_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_38
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
