import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertex_3_8 :
    record.vertexCheck (3 : Fin 40) (8 : Fin 24) = true := by decide +kernel


theorem vertex_3_9 :
    record.vertexCheck (3 : Fin 40) (9 : Fin 24) = true := by decide +kernel


theorem vertex_3_10 :
    record.vertexCheck (3 : Fin 40) (10 : Fin 24) = true := by decide +kernel


theorem vertex_3_11 :
    record.vertexCheck (3 : Fin 40) (11 : Fin 24) = true := by decide +kernel


theorem vertex_3_12 :
    record.vertexCheck (3 : Fin 40) (12 : Fin 24) = true := by decide +kernel


theorem vertex_3_13 :
    record.vertexCheck (3 : Fin 40) (13 : Fin 24) = true := by decide +kernel


theorem vertex_3_14 :
    record.vertexCheck (3 : Fin 40) (14 : Fin 24) = true := by decide +kernel


theorem vertex_3_15 :
    record.vertexCheck (3 : Fin 40) (15 : Fin 24) = true := by decide +kernel


#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_8
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_9
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_10
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_11
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_12
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_13
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_14
#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertex_3_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
