import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex010_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex010_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n40.Vertex010_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n40
open PackingCertificates.Rational

theorem vertices_piece_10 :
    allFin 24 (fun p => record.vertexCheck (10 : Fin 40) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_10_0
  · exact vertex_10_1
  · exact vertex_10_2
  · exact vertex_10_3
  · exact vertex_10_4
  · exact vertex_10_5
  · exact vertex_10_6
  · exact vertex_10_7
  · exact vertex_10_8
  · exact vertex_10_9
  · exact vertex_10_10
  · exact vertex_10_11
  · exact vertex_10_12
  · exact vertex_10_13
  · exact vertex_10_14
  · exact vertex_10_15
  · exact vertex_10_16
  · exact vertex_10_17
  · exact vertex_10_18
  · exact vertex_10_19
  · exact vertex_10_20
  · exact vertex_10_21
  · exact vertex_10_22
  · exact vertex_10_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n40.vertices_piece_10
end PackingCertificates.Catalogue.CIVVRc24inc24_n40
