import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex015_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex015_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex015_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertices_piece_15 :
    allFin 24 (fun p => record.vertexCheck (15 : Fin 17) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_15_0
  · exact vertex_15_1
  · exact vertex_15_2
  · exact vertex_15_3
  · exact vertex_15_4
  · exact vertex_15_5
  · exact vertex_15_6
  · exact vertex_15_7
  · exact vertex_15_8
  · exact vertex_15_9
  · exact vertex_15_10
  · exact vertex_15_11
  · exact vertex_15_12
  · exact vertex_15_13
  · exact vertex_15_14
  · exact vertex_15_15
  · exact vertex_15_16
  · exact vertex_15_17
  · exact vertex_15_18
  · exact vertex_15_19
  · exact vertex_15_20
  · exact vertex_15_21
  · exact vertex_15_22
  · exact vertex_15_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertices_piece_15
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
