import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex014_000
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex014_001
import PackingCertificates.Catalogue.CIVVRc24inc24_n17.Vertex014_002

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CIVVRc24inc24_n17
open PackingCertificates.Rational

theorem vertices_piece_14 :
    allFin 24 (fun p => record.vertexCheck (14 : Fin 17) p) = true := by
  apply allFin_eq_true.mpr
  intro p
  fin_cases p
  · exact vertex_14_0
  · exact vertex_14_1
  · exact vertex_14_2
  · exact vertex_14_3
  · exact vertex_14_4
  · exact vertex_14_5
  · exact vertex_14_6
  · exact vertex_14_7
  · exact vertex_14_8
  · exact vertex_14_9
  · exact vertex_14_10
  · exact vertex_14_11
  · exact vertex_14_12
  · exact vertex_14_13
  · exact vertex_14_14
  · exact vertex_14_15
  · exact vertex_14_16
  · exact vertex_14_17
  · exact vertex_14_18
  · exact vertex_14_19
  · exact vertex_14_20
  · exact vertex_14_21
  · exact vertex_14_22
  · exact vertex_14_23



#print axioms PackingCertificates.Catalogue.CIVVRc24inc24_n17.vertices_piece_14
end PackingCertificates.Catalogue.CIVVRc24inc24_n17
