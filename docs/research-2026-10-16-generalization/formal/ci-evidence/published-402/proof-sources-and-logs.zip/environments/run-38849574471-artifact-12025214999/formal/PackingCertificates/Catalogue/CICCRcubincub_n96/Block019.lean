import PackingCertificates.Catalogue.CICCRcubincub_n96.Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace PackingCertificates.Catalogue.CICCRcubincub_n96
open PackingCertificates.Rational
open PackingCertificates.CubeFast

theorem source_piece_95 :
    (decide (0 < Cube.quaternionNormSq (record.quaternion (95 : Fin 96))) && decide (record.rotation (95 : Fin 96) = Cube.quaternionMatrix (record.quaternion (95 : Fin 96))) && decide (Cube.determinant3 (record.rotation (95 : Fin 96)) = 1)) = true := by decide +kernel

theorem gram_piece_95 :
    allFin 3 (fun a => allFin 3 (fun b => decide (qdot (record.toPlacement.rotation (95 : Fin 96) a) (record.toPlacement.rotation (95 : Fin 96) b) = if a = b then 1 else 0))) = true := by decide +kernel

theorem cache_row_95 :
    AxisFast.cacheRowCheck record cache (95 : Fin 96) = true := by decide +kernel

theorem wall_row_95 : CubeFast.wallRowCheck record (95 : Fin 96) = true := by decide +kernel

theorem pair_row_95 :
    AxisFast.pairRowCheck record cache directions (95 : Fin 96) = true := by decide +kernel

#print axioms source_piece_95
#print axioms gram_piece_95
#print axioms cache_row_95
#print axioms wall_row_95
#print axioms pair_row_95
end PackingCertificates.Catalogue.CICCRcubincub_n96
