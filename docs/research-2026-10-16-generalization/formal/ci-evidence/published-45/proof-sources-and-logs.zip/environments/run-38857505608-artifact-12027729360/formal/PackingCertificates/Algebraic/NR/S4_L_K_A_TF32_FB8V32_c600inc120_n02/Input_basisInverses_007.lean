import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisInverses_group_007 : Array (Unit → Array (Array (Array (ℚ × ℚ)))) := #[(fun _ => #[#[#[⟨(mkRat (Int.ofNat 1) 2), (mkRat (Int.ofNat 1) 2)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩, ⟨(mkRat (Int.ofNat 1) 2), (mkRat (Int.ofNat 1) 2)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩], #[⟨(mkRat (Int.ofNat 3) 1), (mkRat (Int.ofNat 1) 1)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩, ⟨(mkRat (Int.negSucc 6) 4), (mkRat (Int.negSucc 2) 4)⟩, ⟨(mkRat (Int.ofNat 11) 4), (mkRat (Int.ofNat 5) 4)⟩, ⟨(mkRat (Int.negSucc 0) 1), (mkRat (Int.negSucc 0) 2)⟩], #[⟨(mkRat (Int.negSucc 4) 2), (mkRat (Int.negSucc 2) 2)⟩, ⟨(mkRat (Int.negSucc 2) 4), (mkRat (Int.negSucc 0) 4)⟩, ⟨(mkRat (Int.ofNat 7) 4), (mkRat (Int.ofNat 3) 4)⟩, ⟨(mkRat (Int.negSucc 2) 1), (mkRat (Int.negSucc 2) 2)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩], #[⟨(mkRat (Int.negSucc 4) 2), (mkRat (Int.negSucc 0) 2)⟩, ⟨(mkRat (Int.negSucc 0) 4), (mkRat (Int.negSucc 0) 4)⟩, ⟨(mkRat (Int.ofNat 3) 4), (mkRat (Int.ofNat 1) 4)⟩, ⟨(mkRat (Int.negSucc 1) 1), (mkRat (Int.negSucc 0) 1)⟩, ⟨(mkRat (Int.ofNat 1) 1), (mkRat (Int.ofNat 1) 2)⟩], #[⟨(mkRat (Int.ofNat 5) 2), (mkRat (Int.ofNat 1) 2)⟩, ⟨(mkRat (Int.ofNat 1) 1), (mkRat (Int.ofNat 1) 2)⟩, ⟨(mkRat (Int.negSucc 2) 4), (mkRat (Int.negSucc 0) 4)⟩, ⟨(mkRat (Int.ofNat 7) 4), (mkRat (Int.ofNat 3) 4)⟩, ⟨(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)⟩]]])]

#print axioms array_basisInverses_group_007
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
