import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0002
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0003
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0004
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0005
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0006
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0007
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0008
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0009
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0010
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0011
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0012
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0013
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0014
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0015
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0016
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0017
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0018
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0019
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0020
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0021
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0022
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0023
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0024
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0025
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0026
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0027
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Basis0028

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem bases_checked : certificate.basisCheck = true := by
  apply basisCheck_of_items
  intro z
  by_cases h112 : z.val < 112
  · by_cases h56 : z.val < 56
    · by_cases h24 : z.val < 24
      · by_cases h8 : z.val < 8
        · exact rangeCheck_sound bases_range_0 z (by omega) (by omega)
        · by_cases h16 : z.val < 16
          · exact rangeCheck_sound bases_range_1 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_2 z (by omega) (by omega)
      · by_cases h40 : z.val < 40
        · by_cases h32 : z.val < 32
          · exact rangeCheck_sound bases_range_3 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_4 z (by omega) (by omega)
        · by_cases h48 : z.val < 48
          · exact rangeCheck_sound bases_range_5 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_6 z (by omega) (by omega)
    · by_cases h80 : z.val < 80
      · by_cases h64 : z.val < 64
        · exact rangeCheck_sound bases_range_7 z (by omega) (by omega)
        · by_cases h72 : z.val < 72
          · exact rangeCheck_sound bases_range_8 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_9 z (by omega) (by omega)
      · by_cases h96 : z.val < 96
        · by_cases h88 : z.val < 88
          · exact rangeCheck_sound bases_range_10 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_11 z (by omega) (by omega)
        · by_cases h104 : z.val < 104
          · exact rangeCheck_sound bases_range_12 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_13 z (by omega) (by omega)
  · by_cases h168 : z.val < 168
    · by_cases h136 : z.val < 136
      · by_cases h120 : z.val < 120
        · exact rangeCheck_sound bases_range_14 z (by omega) (by omega)
        · by_cases h128 : z.val < 128
          · exact rangeCheck_sound bases_range_15 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_16 z (by omega) (by omega)
      · by_cases h152 : z.val < 152
        · by_cases h144 : z.val < 144
          · exact rangeCheck_sound bases_range_17 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_18 z (by omega) (by omega)
        · by_cases h160 : z.val < 160
          · exact rangeCheck_sound bases_range_19 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_20 z (by omega) (by omega)
    · by_cases h200 : z.val < 200
      · by_cases h184 : z.val < 184
        · by_cases h176 : z.val < 176
          · exact rangeCheck_sound bases_range_21 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_22 z (by omega) (by omega)
        · by_cases h192 : z.val < 192
          · exact rangeCheck_sound bases_range_23 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_24 z (by omega) (by omega)
      · by_cases h216 : z.val < 216
        · by_cases h208 : z.val < 208
          · exact rangeCheck_sound bases_range_25 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_26 z (by omega) (by omega)
        · by_cases h224 : z.val < 224
          · exact rangeCheck_sound bases_range_27 z (by omega) (by omega)
          · exact rangeCheck_sound bases_range_28 z (by omega) (by omega)

#print axioms bases_checked
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
