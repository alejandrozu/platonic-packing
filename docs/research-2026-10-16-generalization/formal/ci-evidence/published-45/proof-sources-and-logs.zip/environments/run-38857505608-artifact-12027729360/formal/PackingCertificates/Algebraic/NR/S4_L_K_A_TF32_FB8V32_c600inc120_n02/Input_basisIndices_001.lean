import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_001 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 435, 514, 596, 437], #[527, 83, 84, 140, 325], #[527, 372, 7, 326, 548], #[527, 36, 33, 126, 142], #[527, 126, 183, 29, 30], #[527, 259, 156, 159, 240], #[527, 81, 436, 78, 75], #[527, 326, 548, 75, 20]]), (fun _ => #[#[527, 436, 75, 437, 20], #[527, 224, 33, 142, 29], #[527, 156, 92, 246, 159], #[527, 32, 28, 33, 126], #[527, 158, 28, 126, 156], #[527, 229, 127, 81, 236], #[527, 227, 235, 140, 82], #[527, 232, 229, 231, 126]]), (fun _ => #[#[527, 237, 240, 241, 280], #[527, 440, 540, 555, 437], #[527, 371, 440, 478, 548], #[527, 342, 30, 437, 2], #[527, 371, 245, 244, 342], #[527, 229, 133, 82, 241], #[527, 371, 440, 245, 75], #[527, 79, 82, 75, 20]]), (fun _ => #[#[527, 548, 75, 437, 20], #[527, 133, 82, 241, 75], #[527, 7, 28, 156, 75], #[527, 175, 181, 133, 435], #[527, 77, 435, 78, 75], #[527, 94, 183, 29, 2], #[527, 77, 126, 183, 2], #[527, 476, 329, 477, 326]])]

#print axioms array_basisIndices_group_001
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
