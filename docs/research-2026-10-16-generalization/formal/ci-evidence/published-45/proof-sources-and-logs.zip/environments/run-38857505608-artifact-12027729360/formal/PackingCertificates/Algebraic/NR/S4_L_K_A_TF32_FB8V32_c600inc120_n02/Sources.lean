import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Export

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem source_piece_0 : sourcePieceCheck certificate 0 = true := by decide +kernel

theorem source_piece_1 : sourcePieceCheck certificate 1 = true := by decide +kernel

theorem templates_checked : certificate.templateCheck = true := by
  change (piece_c600.normalizationCheck && (piece_c600.verticesCheck && (PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120.normalizationCheck && (PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120.verticesCheck && PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120.centroidCheck 2)))) = true
  simp only [piece_c600_normalization_checked, piece_c600_vertices_checked, PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120_normalization_checked, PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120_vertices_checked, PackingCertificates.Algebraic.Generated.ND.Records.FastCanonical.container_c600inc120_centroid_checked] <;> rfl


#print axioms source_piece_0
#print axioms source_piece_1
#print axioms templates_checked
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
