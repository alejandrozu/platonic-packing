import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_000 : Array (Unit → Array (Fin 225)) := #[(fun _ => #[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 17, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]), (fun _ => #[31, 32, 33, 34, 35, 36, 37, 13, 38, 39, 40, 39, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 27, 29, 55, 56, 57, 58]), (fun _ => #[59, 60, 61, 62, 63, 64, 65, 22, 18, 66, 23, 67, 68, 69, 70, 54, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 38, 83, 84, 85]), (fun _ => #[86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 52, 97, 98, 99, 100, 101, 102, 103, 104, 76, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115])]

#print axioms array_vertexBasis_group_000
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
