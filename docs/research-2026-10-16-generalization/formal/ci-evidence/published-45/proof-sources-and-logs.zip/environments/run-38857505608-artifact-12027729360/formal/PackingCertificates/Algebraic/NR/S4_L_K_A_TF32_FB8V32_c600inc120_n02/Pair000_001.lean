import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Pair000_001_0000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Pair000_001_0001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Pair000_001_0002
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Pair000_001_0003

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem pair_vertices_0_1 (p : Fin 120) :
    (pairLeftCheck certificate 0 1 p && pairRightCheck certificate 0 1 p) = true := by
  by_cases h64 : p.val < 64
  · by_cases h32 : p.val < 32
    · exact rangeCheck_sound pair_0_1_range_0 p (by omega) (by omega)
    · exact rangeCheck_sound pair_0_1_range_1 p (by omega) (by omega)
  · by_cases h96 : p.val < 96
    · exact rangeCheck_sound pair_0_1_range_2 p (by omega) (by omega)
    · exact rangeCheck_sound pair_0_1_range_3 p (by omega) (by omega)

theorem pair_0_1 : certificate.pairCheck 0 1 = true := by
  apply pairCheck_of_vertices
  · decide +kernel
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).1
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).2

#print axioms pair_0_1
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
