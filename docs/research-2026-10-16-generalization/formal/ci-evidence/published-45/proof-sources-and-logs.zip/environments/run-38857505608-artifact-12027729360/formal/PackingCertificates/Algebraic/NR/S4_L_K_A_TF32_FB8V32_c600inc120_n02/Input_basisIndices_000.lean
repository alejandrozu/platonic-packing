import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_000 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 132, 181, 127, 133], #[527, 140, 82, 325, 240], #[527, 79, 229, 81, 20], #[527, 84, 140, 82, 325], #[527, 439, 341, 434, 540], #[527, 372, 476, 371, 548], #[527, 540, 435, 596, 437], #[527, 441, 372, 7, 555]]), (fun _ => #[#[527, 128, 36, 231, 126], #[527, 164, 259, 159, 240], #[527, 229, 133, 231, 126], #[527, 239, 162, 227, 241], #[527, 314, 29, 487, 2], #[527, 244, 156, 92, 246], #[527, 77, 30, 75, 2], #[527, 243, 371, 244, 156]]), (fun _ => #[#[527, 556, 555, 437, 20], #[527, 33, 156, 159, 30], #[527, 229, 231, 236, 241], #[527, 371, 440, 245, 342], #[527, 79, 229, 82, 75], #[527, 182, 175, 181, 133], #[527, 257, 329, 156, 467], #[527, 229, 140, 236, 20]]), (fun _ => #[#[527, 79, 229, 140, 20], #[527, 441, 440, 555, 437], #[527, 555, 548, 437, 20], #[527, 126, 142, 159, 241], #[527, 158, 126, 159, 241], #[527, 246, 159, 93, 30], #[527, 245, 244, 156, 30], #[527, 80, 79, 81, 436]])]

#print axioms array_basisIndices_group_000
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
