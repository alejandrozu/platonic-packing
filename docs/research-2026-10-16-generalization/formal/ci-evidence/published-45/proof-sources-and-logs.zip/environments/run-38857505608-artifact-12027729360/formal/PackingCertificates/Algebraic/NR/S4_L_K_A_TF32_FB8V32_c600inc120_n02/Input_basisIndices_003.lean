import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_003 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 342, 487, 30, 2], #[527, 131, 79, 229, 133], #[527, 84, 227, 79, 82], #[527, 342, 30, 75, 437], #[527, 370, 441, 7, 371], #[527, 182, 175, 181, 183], #[527, 175, 97, 179, 2], #[527, 181, 133, 81, 78]]), (fun _ => #[#[527, 175, 77, 434, 435], #[527, 156, 467, 326, 466], #[527, 329, 82, 326, 240], #[527, 371, 82, 326, 466], #[527, 152, 145, 154, 142], #[527, 230, 125, 127, 280], #[527, 217, 180, 98, 95], #[527, 181, 168, 124, 171]]), (fun _ => #[#[527, 116, 43, 216, 37], #[527, 108, 101, 107, 264], #[527, 62, 60, 304, 59], #[527, 66, 112, 59, 65], #[527, 89, 144, 143, 26], #[527, 234, 268, 236, 203], #[527, 315, 312, 489, 314], #[527, 171, 435, 78, 543]]), (fun _ => #[#[527, 120, 114, 40, 332], #[527, 67, 339, 335, 71], #[527, 352, 308, 304, 400], #[527, 419, 429, 66, 65], #[527, 113, 99, 59, 34], #[527, 209, 89, 216, 143], #[527, 28, 77, 126, 156], #[527, 350, 349, 352, 68]])]

#print axioms array_basisIndices_group_003
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
