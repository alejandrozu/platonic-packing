import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Vertices001_0000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Vertices001_0001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Vertices001_0002
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c600inc120_n02.Vertices001_0003

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem vertices_piece_1 (p : Fin 120) :
    (certificate.placedCheck 1 p && certificate.vertexContainmentCheck 1 p) = true := by
  by_cases h64 : p.val < 64
  · by_cases h32 : p.val < 32
    · exact rangeCheck_sound vertices_1_range_0 p (by omega) (by omega)
    · exact rangeCheck_sound vertices_1_range_1 p (by omega) (by omega)
  · by_cases h96 : p.val < 96
    · exact rangeCheck_sound vertices_1_range_2 p (by omega) (by omega)
    · exact rangeCheck_sound vertices_1_range_3 p (by omega) (by omega)

#print axioms vertices_piece_1
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
