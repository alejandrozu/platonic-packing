import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_002 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 379, 477, 326, 327], #[527, 161, 257, 258, 156], #[527, 228, 237, 231, 241], #[527, 227, 229, 82, 241], #[527, 374, 371, 440, 342], #[527, 245, 244, 246, 342], #[527, 441, 371, 440, 437], #[527, 132, 181, 133, 81]]), (fun _ => #[#[527, 133, 124, 126, 183], #[527, 434, 540, 435, 2], #[527, 175, 97, 183, 2], #[527, 329, 326, 240, 327], #[527, 257, 259, 156, 240], #[527, 476, 371, 326, 466], #[527, 244, 82, 156, 466], #[527, 175, 77, 183, 2]]), (fun _ => #[#[527, 98, 94, 33, 183], #[527, 329, 156, 467, 326], #[527, 161, 160, 244, 156], #[527, 133, 77, 126, 75], #[527, 82, 326, 75, 20], #[527, 7, 82, 156, 75], #[527, 127, 133, 231, 124], #[527, 229, 127, 133, 231]]), (fun _ => #[#[527, 229, 236, 240, 241], #[527, 227, 235, 82, 240], #[527, 341, 434, 342, 2], #[527, 434, 342, 437, 2], #[527, 371, 373, 342, 466], #[527, 372, 476, 371, 326], #[527, 128, 231, 126, 183], #[527, 164, 159, 240, 241]])]

#print axioms array_basisIndices_group_002
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
