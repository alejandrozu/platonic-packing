import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_004 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 271, 193, 189, 274], #[527, 62, 1, 292, 345], #[527, 209, 318, 89, 216], #[527, 104, 11, 10, 6], #[527, 145, 141, 231, 34], #[527, 130, 172, 183, 34], #[527, 113, 60, 107, 37], #[527, 113, 60, 59, 65]]), (fun _ => #[#[527, 161, 160, 258, 156], #[527, 341, 540, 314, 2], #[527, 334, 336, 339, 332], #[527, 354, 430, 352, 400], #[527, 225, 35, 224, 34], #[527, 215, 211, 150, 37], #[527, 103, 124, 104, 34], #[527, 110, 112, 113, 104]]), (fun _ => #[#[527, 321, 487, 93, 488], #[527, 281, 322, 394, 454], #[527, 229, 81, 236, 20], #[527, 4, 67, 107, 6], #[527, 141, 142, 150, 144], #[527, 99, 103, 107, 265], #[527, 172, 211, 59, 95], #[527, 56, 110, 168, 35]]), (fun _ => #[#[527, 12, 16, 114, 24], #[527, 274, 196, 273, 200], #[527, 403, 405, 395, 402], #[527, 294, 293, 292, 344], #[527, 129, 36, 126, 183], #[527, 133, 231, 124, 126], #[527, 156, 246, 159, 30], #[527, 68, 63, 67, 43]])]

#print axioms array_basisIndices_group_004
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
