import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_006 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 67, 107, 65, 6], #[527, 286, 283, 70, 67], #[527, 154, 148, 116, 144], #[527, 114, 15, 116, 24], #[527, 263, 273, 264, 280], #[527, 274, 198, 273, 74], #[527, 208, 345, 95, 212], #[527, 405, 345, 395, 212]]), (fun _ => #[#[527, 53, 14, 52, 296], #[527, 511, 292, 539, 296], #[527, 31, 33, 159, 93], #[527, 94, 314, 29, 2], #[527, 235, 229, 140, 236], #[527, 68, 308, 304, 332], #[527, 352, 68, 308, 304], #[527, 311, 68, 67, 339]]), (fun _ => #[#[527, 285, 419, 429, 67], #[527, 152, 164, 154, 85], #[527, 279, 277, 272, 237], #[527, 118, 116, 121, 332], #[527, 115, 107, 121, 264], #[527, 313, 179, 314, 95], #[527, 170, 166, 295, 171], #[527, 307, 430, 352, 305]]), (fun _ => #[#[527, 420, 307, 430, 66], #[527, 216, 144, 319, 143], #[527, 119, 120, 40, 116], #[527, 220, 312, 96, 207], #[527, 304, 281, 394, 212], #[527, 270, 205, 236, 139], #[527, 19, 107, 263, 74], #[527, 44, 48, 46, 296]])]

#print axioms array_basisIndices_group_006
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
