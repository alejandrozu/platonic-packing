import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.Generated.ND.piece_c600
import PackingCertificates.Algebraic.CN.V32_container_c600inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_005 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[527, 63, 113, 67, 60], #[527, 356, 357, 352, 334], #[527, 349, 353, 356, 285], #[527, 262, 153, 228, 271], #[527, 115, 116, 264, 37], #[527, 188, 189, 259, 196], #[527, 194, 116, 121, 333], #[527, 167, 172, 3, 95]]), (fun _ => #[#[527, 61, 17, 52, 62], #[527, 179, 535, 95, 347], #[527, 422, 424, 430, 346], #[527, 142, 150, 223, 143], #[527, 224, 211, 223, 207], #[527, 114, 40, 319, 333], #[527, 399, 216, 395, 394], #[527, 267, 102, 263, 104]]), (fun _ => #[#[527, 53, 14, 112, 45], #[527, 72, 74, 139, 6], #[527, 50, 45, 11, 10], #[527, 165, 152, 231, 241], #[527, 175, 166, 179, 183], #[527, 179, 435, 314, 2], #[527, 122, 69, 67, 118], #[527, 356, 334, 68, 339]]), (fun _ => #[#[527, 429, 18, 68, 62], #[527, 349, 352, 429, 68], #[527, 209, 96, 224, 89], #[527, 88, 320, 486, 89], #[527, 42, 215, 43, 216], #[527, 304, 281, 43, 332], #[527, 124, 236, 10, 280], #[527, 21, 22, 135, 134]])]

#print axioms array_basisIndices_group_005
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c600inc120_n02
