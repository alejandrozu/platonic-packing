import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_007 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[354, 512, 513, 512, 514, 455, 494, 369, 515, 371, 516, 371, 372, 517, 518, 517, 519, 520, 521, 522, 523, 497, 328, 449, 485, 524, 487, 512, 497, 525, 526, 458]), (fun _ => #[527, 528, 529, 530, 531, 530, 531, 531, 532, 533, 518, 517, 534, 535, 536, 537, 538, 539, 540, 541, 529, 532, 372, 542, 543, 544, 545, 544, 546, 546, 547, 549]), (fun _ => #[548, 551, 552, 553, 554, 554, 358, 555, 556, 557, 558, 526, 559, 560, 561, 562, 490, 563, 562, 564, 564, 489, 487, 565, 566, 567, 518, 518, 565, 566, 568, 569]), (fun _ => #[570, 549, 571, 572, 356, 573, 371, 358, 574, 575, 576, 576, 577, 578, 579, 576, 580, 581, 551, 582, 551, 583, 584, 585, 569, 586, 587, 516, 588, 540, 588, 589])]

#print axioms array_vertexBasis_group_007
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
