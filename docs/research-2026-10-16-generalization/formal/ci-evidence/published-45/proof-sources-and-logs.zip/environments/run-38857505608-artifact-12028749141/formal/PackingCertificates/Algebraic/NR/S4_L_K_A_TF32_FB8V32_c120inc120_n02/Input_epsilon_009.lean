import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_epsilon_group_009 : Array (Unit → Array (ℚ)) := #[(fun _ => #[(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)]), (fun _ => #[(mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1), (mkRat (Int.ofNat 0) 1)])]

#print axioms array_epsilon_group_009
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
