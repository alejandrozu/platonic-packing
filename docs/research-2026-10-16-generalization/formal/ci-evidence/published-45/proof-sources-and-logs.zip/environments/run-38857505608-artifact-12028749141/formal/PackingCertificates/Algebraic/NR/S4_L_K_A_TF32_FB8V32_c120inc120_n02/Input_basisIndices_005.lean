import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_005 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 380, 549, 477, 379], #[109, 549, 477, 379, 548], #[109, 469, 473, 475, 477], #[109, 469, 473, 328, 477], #[109, 472, 475, 380, 562], #[109, 360, 473, 475, 379], #[109, 474, 360, 473, 475], #[109, 475, 380, 359, 379]]), (fun _ => #[#[109, 528, 574, 572, 454], #[109, 381, 358, 563, 376], #[109, 358, 563, 566, 359], #[109, 373, 586, 479, 491], #[109, 485, 479, 482, 480], #[109, 478, 373, 485, 480], #[109, 484, 475, 482, 466], #[109, 471, 481, 472, 391]]), (fun _ => #[#[109, 473, 472, 475, 477], #[109, 471, 472, 475, 391], #[109, 479, 587, 477, 480], #[109, 380, 477, 562, 564], #[109, 380, 549, 477, 564], #[109, 549, 587, 477, 598], #[109, 472, 479, 477, 562], #[109, 470, 479, 482, 340]]), (fun _ => #[#[109, 479, 340, 477, 562], #[109, 473, 472, 475, 380], #[109, 587, 592, 585, 596], #[109, 588, 587, 592, 596], #[109, 589, 585, 582, 596], #[109, 370, 480, 440, 548], #[109, 547, 370, 548, 20], #[109, 477, 555, 440, 548]])]

#print axioms array_basisIndices_group_005
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
