import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_006 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 556, 555, 548, 20], #[109, 598, 555, 548, 596], #[109, 559, 546, 551, 557], #[109, 559, 546, 551, 506], #[109, 573, 390, 391, 574], #[109, 573, 390, 574, 459], #[109, 482, 390, 391, 417], #[109, 516, 518, 578, 584]]), (fun _ => #[#[109, 495, 417, 585, 582], #[109, 587, 502, 417, 585], #[109, 377, 450, 451, 287], #[109, 453, 452, 377, 451], #[109, 450, 451, 513, 287], #[109, 575, 577, 578, 574], #[109, 578, 574, 572, 571], #[109, 575, 516, 529, 578]]), (fun _ => #[#[109, 575, 577, 574, 572], #[109, 469, 360, 328, 475], #[109, 581, 340, 458, 582], #[109, 584, 574, 582, 330], #[109, 458, 574, 582, 330], #[109, 581, 458, 582, 330], #[109, 516, 529, 560, 584], #[109, 461, 458, 574, 330]]), (fun _ => #[#[109, 452, 377, 376, 442], #[109, 453, 452, 377, 442], #[109, 559, 551, 506, 513], #[109, 559, 448, 595, 510], #[109, 509, 559, 448, 510], #[109, 584, 589, 585, 582], #[109, 590, 581, 584, 585], #[109, 518, 523, 584, 510]])]

#print axioms array_basisIndices_group_006
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
