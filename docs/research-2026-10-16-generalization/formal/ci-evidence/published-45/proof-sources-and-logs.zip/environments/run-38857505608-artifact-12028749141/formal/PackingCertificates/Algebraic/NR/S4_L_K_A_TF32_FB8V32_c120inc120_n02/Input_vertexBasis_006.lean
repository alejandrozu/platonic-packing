import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_006 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[438, 332, 392, 439, 440, 441, 442, 443, 444, 445, 393, 446, 332, 442, 442, 445, 447, 448, 330, 376, 449, 450, 451, 376, 452, 404, 453, 454, 342, 455, 453, 456]), (fun _ => #[457, 456, 458, 459, 419, 460, 461, 462, 463, 464, 346, 365, 365, 347, 367, 351, 465, 466, 467, 468, 469, 470, 394, 394, 471, 472, 426, 473, 423, 474, 475, 412]), (fun _ => #[476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 201, 311, 312, 52, 311, 487, 487, 488, 489, 490, 491, 456, 455, 492, 493, 494, 495, 492, 376, 496, 497]), (fun _ => #[498, 499, 331, 395, 500, 501, 502, 503, 449, 504, 503, 503, 505, 449, 506, 435, 505, 374, 370, 507, 507, 372, 372, 508, 357, 321, 509, 510, 364, 354, 322, 511])]

#print axioms array_vertexBasis_group_006
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
