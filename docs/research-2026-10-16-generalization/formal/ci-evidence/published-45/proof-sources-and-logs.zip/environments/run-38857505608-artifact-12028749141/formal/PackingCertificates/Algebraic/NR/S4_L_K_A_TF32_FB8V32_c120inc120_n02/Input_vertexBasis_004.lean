import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_004 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[36, 295, 296, 297, 266, 222, 298, 270, 299, 300, 301, 302, 266, 186, 300, 303, 297, 265, 122, 128, 204, 202, 204, 75, 204, 204, 304, 218, 128, 305, 122, 195]), (fun _ => #[306, 16, 307, 106, 64, 163, 189, 191, 0, 308, 146, 18, 60, 292, 309, 37, 51, 310, 52, 311, 311, 171, 201, 312, 200, 171, 313, 314, 315, 316, 213, 303]), (fun _ => #[317, 300, 186, 266, 42, 14, 31, 50, 47, 318, 153, 319, 29, 231, 320, 124, 122, 304, 75, 40, 36, 95, 78, 161, 321, 322, 323, 322, 324, 325, 324, 326]), (fun _ => #[321, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 333, 343, 243, 344, 133, 240, 345, 227, 227, 346, 347, 348, 349, 350, 351])]

#print axioms array_vertexBasis_group_004
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
