import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_007 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 580, 581, 584, 330], #[109, 516, 529, 584, 330], #[109, 485, 482, 504, 413], #[109, 481, 415, 482, 391], #[109, 518, 578, 584, 510], #[109, 529, 527, 578, 528], #[109, 575, 516, 529, 560], #[109, 551, 595, 557, 552]]), (fun _ => #[#[109, 557, 555, 438, 596], #[109, 359, 379, 378, 201], #[109, 381, 358, 376, 379], #[109, 469, 360, 473, 328], #[109, 469, 477, 480, 466], #[109, 482, 477, 480, 466], #[109, 365, 340, 458, 417], #[109, 458, 417, 574, 459]]), (fun _ => #[#[109, 562, 417, 574, 459], #[109, 364, 365, 581, 495], #[109, 365, 461, 581, 458], #[109, 482, 587, 502, 417], #[109, 448, 450, 578, 451], #[109, 450, 578, 451, 449], #[109, 578, 445, 449, 571], #[109, 448, 518, 578, 451]]), (fun _ => #[#[109, 518, 578, 523, 521], #[109, 448, 518, 451, 510], #[109, 448, 518, 450, 510], #[109, 448, 518, 450, 449], #[109, 529, 518, 578, 523], #[109, 525, 448, 518, 578], #[109, 578, 523, 528, 521], #[109, 568, 566, 572, 571]])]

#print axioms array_basisIndices_group_007
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
