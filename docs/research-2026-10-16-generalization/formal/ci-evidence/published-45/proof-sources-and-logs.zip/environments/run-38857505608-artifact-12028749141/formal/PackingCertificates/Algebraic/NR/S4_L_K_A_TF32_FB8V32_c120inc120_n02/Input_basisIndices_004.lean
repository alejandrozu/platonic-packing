import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_004 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 377, 506, 451, 287], #[109, 551, 377, 506, 451], #[109, 553, 377, 547, 378], #[109, 553, 554, 377, 378], #[109, 550, 553, 551, 377], #[109, 391, 562, 417, 459], #[109, 482, 587, 340, 417], #[109, 481, 472, 482, 391]]), (fun _ => #[#[109, 482, 391, 562, 417], #[109, 472, 482, 340, 562], #[109, 587, 340, 417, 582], #[109, 340, 477, 562, 582], #[109, 561, 340, 562, 574], #[109, 340, 458, 417, 574], #[109, 340, 562, 417, 574], #[109, 472, 475, 482, 477]]), (fun _ => #[#[109, 482, 340, 562, 417], #[109, 475, 482, 477, 466], #[109, 476, 469, 477, 480], #[109, 469, 475, 477, 466], #[109, 479, 482, 477, 480], #[109, 476, 372, 477, 480], #[109, 578, 451, 449, 571], #[109, 570, 578, 569, 564]]), (fun _ => #[#[109, 578, 451, 584, 510], #[109, 451, 569, 552, 378], #[109, 570, 560, 578, 564], #[109, 451, 569, 449, 442], #[109, 570, 578, 451, 552], #[109, 565, 570, 560, 564], #[109, 473, 328, 477, 379], #[109, 475, 380, 391, 359]])]

#print axioms array_basisIndices_group_004
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
