import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_008 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 573, 574, 572, 459], #[109, 573, 566, 391, 572], #[109, 574, 572, 459, 454], #[109, 575, 529, 527, 574], #[109, 576, 575, 577, 572], #[109, 595, 513, 557, 510], #[109, 595, 506, 513, 557], #[109, 448, 595, 451, 510]]), (fun _ => #[#[109, 559, 595, 513, 510], #[109, 584, 589, 510, 330], #[109, 592, 589, 585, 596], #[109, 584, 589, 552, 510], #[109, 595, 557, 510, 596], #[109, 513, 508, 557, 510], #[109, 590, 508, 589, 596], #[109, 136, 377, 287, 378]]), (fun _ => #[#[109, 202, 136, 378, 20], #[109, 547, 287, 378, 20], #[109, 588, 587, 374, 440], #[109, 373, 586, 479, 374], #[109, 586, 491, 587, 585], #[109, 588, 555, 440, 596], #[109, 587, 477, 374, 440], #[109, 529, 584, 574, 330]]), (fun _ => #[#[109, 581, 584, 582, 330], #[109, 515, 516, 529, 523], #[109, 516, 523, 584, 330], #[109, 362, 461, 581, 330], #[109, 481, 472, 475, 482], #[109, 475, 380, 391, 562], #[109, 566, 391, 393, 572], #[109, 573, 390, 391, 572]])]

#print axioms array_basisIndices_group_008
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
