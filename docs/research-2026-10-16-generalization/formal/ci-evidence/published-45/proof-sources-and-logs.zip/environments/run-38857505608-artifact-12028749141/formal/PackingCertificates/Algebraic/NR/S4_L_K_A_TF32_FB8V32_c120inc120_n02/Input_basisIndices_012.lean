import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_012 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 485, 482, 502, 504], #[109, 504, 409, 417, 505], #[109, 258, 302, 161, 466], #[109, 485, 482, 480, 466], #[109, 415, 475, 391, 413], #[109, 481, 484, 475, 482], #[109, 467, 469, 468, 466], #[109, 390, 384, 464, 459]]), (fun _ => #[#[109, 338, 281, 319, 333], #[109, 338, 300, 459, 454], #[109, 186, 197, 25, 297], #[109, 15, 12, 319, 26], #[109, 186, 155, 25, 195], #[109, 144, 16, 149, 15], #[109, 299, 12, 300, 26], #[109, 24, 25, 299, 12]]), (fun _ => #[#[109, 155, 152, 15, 143], #[109, 155, 25, 149, 15], #[109, 16, 149, 15, 12], #[109, 25, 195, 15, 12], #[109, 163, 159, 157, 152], #[109, 155, 25, 157, 152], #[109, 85, 163, 155, 25], #[109, 85, 189, 163, 155]]), (fun _ => #[#[109, 163, 155, 157, 152], #[109, 155, 151, 272, 152], #[109, 155, 149, 152, 143], #[109, 481, 484, 415, 475], #[109, 413, 299, 393, 300], #[109, 390, 413, 384, 300], #[109, 412, 418, 410, 417], #[109, 390, 410, 300, 459]])]

#print axioms array_basisIndices_group_012
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
