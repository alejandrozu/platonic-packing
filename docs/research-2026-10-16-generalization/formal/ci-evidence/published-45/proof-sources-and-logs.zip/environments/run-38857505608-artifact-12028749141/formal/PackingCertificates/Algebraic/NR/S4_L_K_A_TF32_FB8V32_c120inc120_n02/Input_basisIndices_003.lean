import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_003 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 554, 380, 549, 378], #[109, 376, 569, 379, 378], #[109, 549, 379, 378, 548], #[109, 569, 552, 378, 564], #[109, 380, 379, 552, 378], #[109, 328, 379, 378, 548], #[109, 549, 547, 378, 548], #[109, 477, 480, 440, 548]]), (fun _ => #[#[109, 372, 370, 480, 548], #[109, 372, 326, 477, 548], #[109, 469, 326, 328, 477], #[109, 563, 566, 379, 564], #[109, 574, 572, 571, 564], #[109, 578, 569, 574, 564], #[109, 560, 562, 574, 564], #[109, 380, 562, 379, 564]]), (fun _ => #[#[109, 566, 379, 393, 564], #[109, 477, 562, 582, 564], #[109, 566, 562, 393, 564], #[109, 358, 563, 359, 379], #[109, 563, 566, 359, 379], #[109, 566, 359, 379, 393], #[109, 360, 475, 359, 379], #[109, 391, 359, 562, 393]]), (fun _ => #[#[109, 472, 475, 391, 562], #[109, 562, 379, 393, 564], #[109, 546, 551, 377, 506], #[109, 553, 546, 551, 547], #[109, 550, 553, 546, 551], #[109, 551, 554, 377, 552], #[109, 554, 377, 552, 378], #[109, 377, 376, 451, 378]])]

#print axioms array_basisIndices_group_003
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
