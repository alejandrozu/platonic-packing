import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0002
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0003
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0004
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0005
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0006
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0007
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0008
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0009
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0010
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0011
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0012
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0013
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0014
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0015
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0016
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0017
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0018
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0019
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0020
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0021
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0022
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0023
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0024
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0025
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0026
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0027
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0028
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0029
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0030
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0031
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0032
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0033
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0034
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0035
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0036
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0037
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0038
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0039
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0040
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0041
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0042
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0043
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0044
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0045
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0046
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0047
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0048
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0049
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0050
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0051
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0052
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0053
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0054
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0055
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0056
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0057
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0058
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0059
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0060
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0061
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0062
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0063
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0064
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0065
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0066
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0067
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0068
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0069
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0070
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0071
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0072
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0073
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0074
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0075
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0076
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0077
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0078
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0079
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0080
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0081
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0082
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0083
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0084
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Basis0085

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem bases_checked : certificate.basisCheck = true := by
  apply basisCheck_of_items
  intro z
  by_cases h344 : z.val < 344
  · by_cases h168 : z.val < 168
    · by_cases h80 : z.val < 80
      · by_cases h40 : z.val < 40
        · by_cases h16 : z.val < 16
          · by_cases h8 : z.val < 8
            · exact rangeCheck_sound bases_range_0 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_1 z (by omega) (by omega)
          · by_cases h24 : z.val < 24
            · exact rangeCheck_sound bases_range_2 z (by omega) (by omega)
            · by_cases h32 : z.val < 32
              · exact rangeCheck_sound bases_range_3 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_4 z (by omega) (by omega)
        · by_cases h56 : z.val < 56
          · by_cases h48 : z.val < 48
            · exact rangeCheck_sound bases_range_5 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_6 z (by omega) (by omega)
          · by_cases h64 : z.val < 64
            · exact rangeCheck_sound bases_range_7 z (by omega) (by omega)
            · by_cases h72 : z.val < 72
              · exact rangeCheck_sound bases_range_8 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_9 z (by omega) (by omega)
      · by_cases h120 : z.val < 120
        · by_cases h96 : z.val < 96
          · by_cases h88 : z.val < 88
            · exact rangeCheck_sound bases_range_10 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_11 z (by omega) (by omega)
          · by_cases h104 : z.val < 104
            · exact rangeCheck_sound bases_range_12 z (by omega) (by omega)
            · by_cases h112 : z.val < 112
              · exact rangeCheck_sound bases_range_13 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_14 z (by omega) (by omega)
        · by_cases h144 : z.val < 144
          · by_cases h128 : z.val < 128
            · exact rangeCheck_sound bases_range_15 z (by omega) (by omega)
            · by_cases h136 : z.val < 136
              · exact rangeCheck_sound bases_range_16 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_17 z (by omega) (by omega)
          · by_cases h152 : z.val < 152
            · exact rangeCheck_sound bases_range_18 z (by omega) (by omega)
            · by_cases h160 : z.val < 160
              · exact rangeCheck_sound bases_range_19 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_20 z (by omega) (by omega)
    · by_cases h256 : z.val < 256
      · by_cases h208 : z.val < 208
        · by_cases h184 : z.val < 184
          · by_cases h176 : z.val < 176
            · exact rangeCheck_sound bases_range_21 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_22 z (by omega) (by omega)
          · by_cases h192 : z.val < 192
            · exact rangeCheck_sound bases_range_23 z (by omega) (by omega)
            · by_cases h200 : z.val < 200
              · exact rangeCheck_sound bases_range_24 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_25 z (by omega) (by omega)
        · by_cases h232 : z.val < 232
          · by_cases h216 : z.val < 216
            · exact rangeCheck_sound bases_range_26 z (by omega) (by omega)
            · by_cases h224 : z.val < 224
              · exact rangeCheck_sound bases_range_27 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_28 z (by omega) (by omega)
          · by_cases h240 : z.val < 240
            · exact rangeCheck_sound bases_range_29 z (by omega) (by omega)
            · by_cases h248 : z.val < 248
              · exact rangeCheck_sound bases_range_30 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_31 z (by omega) (by omega)
      · by_cases h296 : z.val < 296
        · by_cases h272 : z.val < 272
          · by_cases h264 : z.val < 264
            · exact rangeCheck_sound bases_range_32 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_33 z (by omega) (by omega)
          · by_cases h280 : z.val < 280
            · exact rangeCheck_sound bases_range_34 z (by omega) (by omega)
            · by_cases h288 : z.val < 288
              · exact rangeCheck_sound bases_range_35 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_36 z (by omega) (by omega)
        · by_cases h320 : z.val < 320
          · by_cases h304 : z.val < 304
            · exact rangeCheck_sound bases_range_37 z (by omega) (by omega)
            · by_cases h312 : z.val < 312
              · exact rangeCheck_sound bases_range_38 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_39 z (by omega) (by omega)
          · by_cases h328 : z.val < 328
            · exact rangeCheck_sound bases_range_40 z (by omega) (by omega)
            · by_cases h336 : z.val < 336
              · exact rangeCheck_sound bases_range_41 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_42 z (by omega) (by omega)
  · by_cases h512 : z.val < 512
    · by_cases h424 : z.val < 424
      · by_cases h384 : z.val < 384
        · by_cases h360 : z.val < 360
          · by_cases h352 : z.val < 352
            · exact rangeCheck_sound bases_range_43 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_44 z (by omega) (by omega)
          · by_cases h368 : z.val < 368
            · exact rangeCheck_sound bases_range_45 z (by omega) (by omega)
            · by_cases h376 : z.val < 376
              · exact rangeCheck_sound bases_range_46 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_47 z (by omega) (by omega)
        · by_cases h400 : z.val < 400
          · by_cases h392 : z.val < 392
            · exact rangeCheck_sound bases_range_48 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_49 z (by omega) (by omega)
          · by_cases h408 : z.val < 408
            · exact rangeCheck_sound bases_range_50 z (by omega) (by omega)
            · by_cases h416 : z.val < 416
              · exact rangeCheck_sound bases_range_51 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_52 z (by omega) (by omega)
      · by_cases h464 : z.val < 464
        · by_cases h440 : z.val < 440
          · by_cases h432 : z.val < 432
            · exact rangeCheck_sound bases_range_53 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_54 z (by omega) (by omega)
          · by_cases h448 : z.val < 448
            · exact rangeCheck_sound bases_range_55 z (by omega) (by omega)
            · by_cases h456 : z.val < 456
              · exact rangeCheck_sound bases_range_56 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_57 z (by omega) (by omega)
        · by_cases h488 : z.val < 488
          · by_cases h472 : z.val < 472
            · exact rangeCheck_sound bases_range_58 z (by omega) (by omega)
            · by_cases h480 : z.val < 480
              · exact rangeCheck_sound bases_range_59 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_60 z (by omega) (by omega)
          · by_cases h496 : z.val < 496
            · exact rangeCheck_sound bases_range_61 z (by omega) (by omega)
            · by_cases h504 : z.val < 504
              · exact rangeCheck_sound bases_range_62 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_63 z (by omega) (by omega)
    · by_cases h600 : z.val < 600
      · by_cases h552 : z.val < 552
        · by_cases h528 : z.val < 528
          · by_cases h520 : z.val < 520
            · exact rangeCheck_sound bases_range_64 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_65 z (by omega) (by omega)
          · by_cases h536 : z.val < 536
            · exact rangeCheck_sound bases_range_66 z (by omega) (by omega)
            · by_cases h544 : z.val < 544
              · exact rangeCheck_sound bases_range_67 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_68 z (by omega) (by omega)
        · by_cases h576 : z.val < 576
          · by_cases h560 : z.val < 560
            · exact rangeCheck_sound bases_range_69 z (by omega) (by omega)
            · by_cases h568 : z.val < 568
              · exact rangeCheck_sound bases_range_70 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_71 z (by omega) (by omega)
          · by_cases h584 : z.val < 584
            · exact rangeCheck_sound bases_range_72 z (by omega) (by omega)
            · by_cases h592 : z.val < 592
              · exact rangeCheck_sound bases_range_73 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_74 z (by omega) (by omega)
      · by_cases h640 : z.val < 640
        · by_cases h616 : z.val < 616
          · by_cases h608 : z.val < 608
            · exact rangeCheck_sound bases_range_75 z (by omega) (by omega)
            · exact rangeCheck_sound bases_range_76 z (by omega) (by omega)
          · by_cases h624 : z.val < 624
            · exact rangeCheck_sound bases_range_77 z (by omega) (by omega)
            · by_cases h632 : z.val < 632
              · exact rangeCheck_sound bases_range_78 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_79 z (by omega) (by omega)
        · by_cases h664 : z.val < 664
          · by_cases h648 : z.val < 648
            · exact rangeCheck_sound bases_range_80 z (by omega) (by omega)
            · by_cases h656 : z.val < 656
              · exact rangeCheck_sound bases_range_81 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_82 z (by omega) (by omega)
          · by_cases h672 : z.val < 672
            · exact rangeCheck_sound bases_range_83 z (by omega) (by omega)
            · by_cases h680 : z.val < 680
              · exact rangeCheck_sound bases_range_84 z (by omega) (by omega)
              · exact rangeCheck_sound bases_range_85 z (by omega) (by omega)

#print axioms bases_checked
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
