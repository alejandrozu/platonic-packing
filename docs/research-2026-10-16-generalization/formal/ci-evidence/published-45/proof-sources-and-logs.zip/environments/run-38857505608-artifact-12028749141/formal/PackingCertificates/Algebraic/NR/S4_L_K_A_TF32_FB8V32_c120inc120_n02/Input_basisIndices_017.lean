import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_017 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 225, 146, 223, 145], #[109, 215, 225, 223, 214], #[109, 225, 223, 145, 141], #[109, 91, 87, 29, 93], #[109, 87, 246, 29, 487], #[109, 91, 246, 29, 93], #[109, 29, 487, 494, 30], #[109, 246, 29, 93, 30]]), (fun _ => #[#[109, 219, 208, 207, 95], #[109, 87, 218, 29, 209], #[109, 396, 315, 219, 395], #[109, 318, 216, 40, 207], #[109, 223, 216, 40, 143], #[109, 318, 40, 209, 319], #[109, 502, 504, 495, 505], #[109, 495, 487, 505, 490]]), (fun _ => #[#[109, 496, 497, 499, 495], #[109, 496, 497, 407, 495], #[109, 87, 487, 93, 488], #[109, 320, 87, 89, 488], #[109, 87, 489, 29, 487], #[109, 142, 33, 146, 93], #[109, 33, 146, 29, 93], #[109, 33, 29, 32, 93]]), (fun _ => #[#[109, 96, 98, 87, 29], #[109, 96, 87, 315, 29], #[109, 29, 209, 93, 143], #[109, 223, 149, 216, 40], #[109, 40, 281, 12, 333], #[109, 323, 410, 242, 319], #[109, 223, 216, 217, 214], #[109, 216, 40, 214, 37]])]

#print axioms array_basisIndices_group_017
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
