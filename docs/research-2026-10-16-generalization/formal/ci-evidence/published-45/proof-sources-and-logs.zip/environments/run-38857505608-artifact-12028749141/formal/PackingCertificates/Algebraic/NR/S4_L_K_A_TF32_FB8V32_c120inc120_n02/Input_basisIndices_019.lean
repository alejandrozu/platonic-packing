import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_019 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 224, 225, 226, 146], #[109, 225, 223, 217, 214], #[109, 220, 96, 218, 219], #[109, 96, 218, 315, 219], #[109, 223, 216, 217, 209], #[109, 217, 209, 207, 212], #[109, 218, 146, 29, 209], #[109, 98, 87, 218, 29]]), (fun _ => #[#[109, 218, 226, 146, 209], #[109, 373, 491, 374, 480], #[109, 342, 246, 374, 487], #[109, 493, 491, 342, 487], #[109, 489, 29, 494, 2], #[109, 489, 29, 487, 494], #[109, 491, 495, 487, 490], #[109, 500, 494, 490, 488]]), (fun _ => #[#[109, 505, 494, 490, 488], #[109, 499, 489, 500, 490], #[109, 315, 489, 494, 2], #[109, 491, 342, 374, 494], #[109, 342, 246, 341, 487], #[109, 491, 487, 494, 490], #[109, 418, 410, 502, 417], #[109, 395, 402, 406, 394]]), (fun _ => #[#[109, 496, 499, 407, 495], #[109, 404, 500, 395, 402], #[109, 407, 495, 458, 406], #[109, 502, 462, 417, 406], #[109, 396, 498, 404, 395], #[109, 399, 500, 395, 394], #[109, 318, 500, 395, 488], #[109, 324, 322, 406, 394]])]

#print axioms array_basisIndices_group_019
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
