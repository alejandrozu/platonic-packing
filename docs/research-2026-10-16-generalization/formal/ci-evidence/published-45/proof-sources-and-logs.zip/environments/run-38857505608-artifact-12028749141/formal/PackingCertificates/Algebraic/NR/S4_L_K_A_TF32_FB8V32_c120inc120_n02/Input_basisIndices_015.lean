import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_015 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 410, 413, 409, 300], #[109, 157, 413, 466, 26], #[109, 484, 302, 413, 466], #[109, 484, 411, 485, 413], #[109, 484, 411, 413, 466], #[109, 484, 415, 482, 413], #[109, 33, 159, 32, 93], #[109, 146, 29, 93, 143]]), (fun _ => #[#[109, 89, 209, 93, 143], #[109, 91, 87, 246, 93], #[109, 87, 89, 93, 488], #[109, 491, 504, 374, 480], #[109, 247, 504, 246, 466], #[109, 485, 491, 504, 480], #[109, 243, 246, 374, 466], #[109, 244, 247, 243, 466]]), (fun _ => #[#[109, 302, 157, 255, 26], #[109, 152, 15, 143, 26], #[109, 25, 152, 15, 26], #[109, 25, 299, 255, 26], #[109, 92, 86, 247, 160], #[109, 86, 90, 93, 26], #[109, 90, 409, 15, 26], #[109, 157, 152, 93, 26]]), (fun _ => #[#[109, 86, 160, 93, 26], #[109, 413, 299, 409, 26], #[109, 302, 157, 413, 26], #[109, 223, 40, 15, 143], #[109, 320, 89, 321, 488], #[109, 318, 500, 319, 488], #[109, 318, 321, 209, 319], #[109, 324, 40, 281, 319]])]

#print axioms array_basisIndices_group_015
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
