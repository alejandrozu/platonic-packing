import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem pair_0_1_range_16 : rangeCheck 512 32 (by decide)
    (fun p => pairLeftCheck certificate 0 1 p && pairRightCheck certificate 0 1 p) = true := by decide +kernel

#print axioms pair_0_1_range_16
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
