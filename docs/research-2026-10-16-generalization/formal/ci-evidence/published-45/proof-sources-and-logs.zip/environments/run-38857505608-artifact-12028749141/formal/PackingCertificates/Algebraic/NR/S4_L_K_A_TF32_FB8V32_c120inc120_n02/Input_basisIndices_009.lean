import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_009 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 447, 250, 569, 571], #[109, 525, 448, 578, 449], #[109, 526, 518, 578, 521], #[109, 577, 578, 572, 571], #[109, 545, 546, 547, 556], #[109, 595, 557, 552, 596], #[109, 559, 595, 506, 557], #[109, 556, 557, 555, 548]]), (fun _ => #[#[109, 546, 547, 287, 20], #[109, 427, 589, 510, 330], #[109, 591, 590, 592, 596], #[109, 590, 592, 589, 596], #[109, 590, 592, 589, 585], #[109, 590, 427, 589, 330], #[109, 508, 589, 510, 596], #[109, 580, 593, 581, 584]]), (fun _ => #[#[109, 559, 551, 448, 513], #[109, 546, 377, 506, 287], #[109, 558, 559, 546, 506], #[109, 325, 547, 370, 548], #[109, 476, 469, 372, 480], #[109, 547, 556, 548, 20], #[109, 365, 581, 340, 458], #[109, 479, 491, 482, 587]]), (fun _ => #[#[109, 365, 340, 495, 417], #[109, 586, 588, 374, 585], #[109, 491, 587, 502, 585], #[109, 364, 362, 581, 495], #[109, 364, 362, 365, 581], #[109, 593, 581, 585, 330], #[109, 570, 451, 569, 552], #[109, 549, 477, 552, 564]])]

#print axioms array_basisIndices_group_009
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
