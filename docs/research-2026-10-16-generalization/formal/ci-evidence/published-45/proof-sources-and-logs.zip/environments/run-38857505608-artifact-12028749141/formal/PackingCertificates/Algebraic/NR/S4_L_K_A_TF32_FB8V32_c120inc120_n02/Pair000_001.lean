import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0002
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0003
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0004
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0005
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0006
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0007
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0008
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0009
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0010
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0011
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0012
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0013
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0014
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0015
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0016
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0017
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001_0018

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem pair_vertices_0_1 (p : Fin 600) :
    (pairLeftCheck certificate 0 1 p && pairRightCheck certificate 0 1 p) = true := by
  by_cases h288 : p.val < 288
  · by_cases h128 : p.val < 128
    · by_cases h64 : p.val < 64
      · by_cases h32 : p.val < 32
        · exact rangeCheck_sound pair_0_1_range_0 p (by omega) (by omega)
        · exact rangeCheck_sound pair_0_1_range_1 p (by omega) (by omega)
      · by_cases h96 : p.val < 96
        · exact rangeCheck_sound pair_0_1_range_2 p (by omega) (by omega)
        · exact rangeCheck_sound pair_0_1_range_3 p (by omega) (by omega)
    · by_cases h192 : p.val < 192
      · by_cases h160 : p.val < 160
        · exact rangeCheck_sound pair_0_1_range_4 p (by omega) (by omega)
        · exact rangeCheck_sound pair_0_1_range_5 p (by omega) (by omega)
      · by_cases h224 : p.val < 224
        · exact rangeCheck_sound pair_0_1_range_6 p (by omega) (by omega)
        · by_cases h256 : p.val < 256
          · exact rangeCheck_sound pair_0_1_range_7 p (by omega) (by omega)
          · exact rangeCheck_sound pair_0_1_range_8 p (by omega) (by omega)
  · by_cases h448 : p.val < 448
    · by_cases h352 : p.val < 352
      · by_cases h320 : p.val < 320
        · exact rangeCheck_sound pair_0_1_range_9 p (by omega) (by omega)
        · exact rangeCheck_sound pair_0_1_range_10 p (by omega) (by omega)
      · by_cases h384 : p.val < 384
        · exact rangeCheck_sound pair_0_1_range_11 p (by omega) (by omega)
        · by_cases h416 : p.val < 416
          · exact rangeCheck_sound pair_0_1_range_12 p (by omega) (by omega)
          · exact rangeCheck_sound pair_0_1_range_13 p (by omega) (by omega)
    · by_cases h512 : p.val < 512
      · by_cases h480 : p.val < 480
        · exact rangeCheck_sound pair_0_1_range_14 p (by omega) (by omega)
        · exact rangeCheck_sound pair_0_1_range_15 p (by omega) (by omega)
      · by_cases h544 : p.val < 544
        · exact rangeCheck_sound pair_0_1_range_16 p (by omega) (by omega)
        · by_cases h576 : p.val < 576
          · exact rangeCheck_sound pair_0_1_range_17 p (by omega) (by omega)
          · exact rangeCheck_sound pair_0_1_range_18 p (by omega) (by omega)

theorem pair_0_1 : certificate.pairCheck 0 1 = true := by
  apply pairCheck_of_vertices
  · decide +kernel
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).1
  · intro p; exact (Bool.and_eq_true_iff.mp (pair_vertices_0_1 p)).2

#print axioms pair_0_1
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
