import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_008 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[590, 540, 540, 591, 545, 592, 593, 575, 589, 571, 594, 595, 596, 597, 598, 597, 599, 600, 321, 488, 601, 602, 321, 518, 603, 601, 557, 604, 605, 606, 607, 608]), (fun _ => #[608, 609, 610, 611, 612, 613, 614, 615, 614, 616, 617, 528, 618, 619, 586, 620, 585, 621, 550, 550, 622, 623, 624, 625, 622, 620, 626, 627, 628, 629, 535, 312]), (fun _ => #[630, 594, 631, 632, 633, 634, 635, 636, 637, 638, 639, 637, 598, 640, 641, 642, 643, 644, 645, 645, 646, 580, 647, 648, 646, 646, 649, 579, 613, 650, 651, 652]), (fun _ => #[574, 609, 609, 574, 612, 651, 653, 650, 609, 579, 654, 655, 520, 655, 656, 591, 657, 576, 576, 576, 658, 659, 649, 654, 648, 660, 661, 624, 662, 640, 604, 604])]

#print axioms array_vertexBasis_group_008
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
