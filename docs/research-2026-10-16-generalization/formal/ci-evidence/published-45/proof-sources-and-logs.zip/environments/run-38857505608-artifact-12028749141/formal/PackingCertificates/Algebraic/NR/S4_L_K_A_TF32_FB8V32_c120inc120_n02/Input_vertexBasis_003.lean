import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_003 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[239, 240, 200, 241, 242, 213, 239, 240, 243, 198, 228, 244, 245, 246, 247, 248, 228, 249, 250, 251, 247, 249, 252, 253, 254, 66, 208, 255, 256, 257, 206, 258]), (fun _ => #[259, 208, 260, 46, 261, 262, 263, 261, 219, 220, 264, 261, 265, 266, 267, 268, 269, 270, 271, 59, 61, 272, 273, 57, 127, 56, 274, 275, 187, 186, 15, 276]), (fun _ => #[277, 187, 277, 15, 275, 278, 279, 225, 280, 223, 279, 279, 281, 282, 214, 212, 212, 283, 117, 159, 198, 159, 240, 133, 136, 143, 284, 227, 159, 185, 112, 285]), (fun _ => #[117, 196, 9, 286, 287, 66, 67, 288, 150, 155, 155, 67, 150, 76, 76, 150, 289, 290, 150, 245, 150, 205, 291, 108, 70, 291, 8, 292, 36, 232, 293, 294])]

#print axioms array_vertexBasis_group_003
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
