import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_002 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 328, 477, 379, 548], #[109, 567, 566, 391, 562], #[109, 566, 562, 572, 564], #[109, 569, 449, 442, 571], #[109, 578, 569, 574, 571], #[109, 566, 569, 571, 564], #[109, 566, 572, 571, 564], #[109, 376, 250, 569, 382]]), (fun _ => #[#[109, 566, 376, 569, 382], #[109, 563, 566, 376, 569], #[109, 452, 376, 451, 569], #[109, 506, 451, 513, 287], #[109, 452, 451, 569, 442], #[109, 477, 552, 582, 564], #[109, 599, 549, 587, 555], #[109, 554, 380, 549, 552]]), (fun _ => #[#[109, 549, 547, 552, 548], #[109, 380, 549, 552, 564], #[109, 599, 549, 587, 598], #[109, 587, 477, 598, 582], #[109, 549, 598, 552, 548], #[109, 549, 598, 555, 548], #[109, 477, 598, 552, 582], #[109, 560, 340, 574, 582]]), (fun _ => #[#[109, 560, 562, 582, 564], #[109, 561, 560, 340, 562], #[109, 560, 584, 574, 582], #[109, 561, 560, 340, 574], #[109, 529, 560, 584, 574], #[109, 581, 340, 495, 582], #[109, 583, 560, 584, 582], #[109, 553, 554, 547, 378]])]

#print axioms array_basisIndices_group_002
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
