import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_001 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[99, 99, 100, 101, 102, 24, 103, 103, 104, 105, 63, 53, 106, 77, 107, 69, 108, 99, 30, 99, 109, 110, 31, 111, 112, 113, 113, 114, 115, 114, 115, 116]), (fun _ => #[117, 117, 118, 119, 120, 121, 122, 122, 123, 124, 122, 124, 125, 59, 59, 126, 29, 127, 127, 128, 129, 130, 131, 127, 126, 132, 133, 134, 135, 136, 137, 138]), (fun _ => #[139, 140, 141, 142, 136, 135, 134, 143, 144, 145, 146, 147, 148, 145, 149, 150, 43, 151, 151, 14, 152, 153, 14, 34, 154, 153, 153, 150, 155, 156, 157, 109]), (fun _ => #[99, 99, 151, 158, 159, 101, 64, 160, 64, 161, 162, 163, 64, 164, 159, 165, 166, 167, 168, 169, 170, 72, 71, 72, 54, 54, 171, 172, 173, 159, 174, 175])]

#print axioms array_vertexBasis_group_001
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
