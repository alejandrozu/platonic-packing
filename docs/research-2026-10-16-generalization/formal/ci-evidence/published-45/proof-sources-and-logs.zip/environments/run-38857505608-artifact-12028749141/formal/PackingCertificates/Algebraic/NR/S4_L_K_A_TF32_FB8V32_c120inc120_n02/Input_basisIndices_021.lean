import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_021 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 218, 226, 217, 209], #[109, 219, 217, 209, 207], #[109, 395, 207, 347, 212], #[109, 396, 498, 315, 395], #[109, 219, 489, 395, 207], #[109, 489, 395, 207, 488], #[109, 499, 404, 500, 402], #[109, 498, 315, 489, 404]]), (fun _ => #[#[109, 407, 500, 402, 406], #[109, 500, 395, 406, 394], #[109, 499, 407, 500, 402], #[109, 498, 489, 500, 395]])]

#print axioms array_basisIndices_group_021
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
