import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_010 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 558, 559, 546, 557], #[109, 321, 209, 319, 143], #[109, 120, 40, 281, 333], #[109, 462, 417, 406, 459], #[109, 40, 15, 319, 143], #[109, 16, 223, 40, 15], #[109, 482, 502, 504, 417], #[109, 321, 15, 319, 143]]), (fun _ => #[#[109, 409, 300, 319, 26], #[109, 409, 15, 319, 26], #[109, 160, 159, 157, 161], #[109, 12, 300, 319, 26], #[109, 338, 12, 319, 333], #[109, 253, 258, 161, 466], #[109, 157, 161, 158, 240], #[109, 119, 120, 12, 333]]), (fun _ => #[#[109, 144, 155, 149, 15], #[109, 144, 155, 15, 143], #[109, 418, 500, 322, 505], #[109, 410, 321, 505, 319], #[109, 410, 322, 505, 319], #[109, 410, 409, 300, 319], #[109, 159, 161, 158, 93], #[109, 243, 480, 161, 466]]), (fun _ => #[#[109, 390, 391, 417, 459], #[109, 471, 481, 472, 475], #[109, 299, 12, 200, 300], #[109, 12, 200, 300, 333], #[109, 390, 391, 413, 384], #[109, 189, 186, 155, 25], #[109, 163, 25, 157, 255], #[109, 155, 25, 149, 195]])]

#print axioms array_basisIndices_group_010
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
