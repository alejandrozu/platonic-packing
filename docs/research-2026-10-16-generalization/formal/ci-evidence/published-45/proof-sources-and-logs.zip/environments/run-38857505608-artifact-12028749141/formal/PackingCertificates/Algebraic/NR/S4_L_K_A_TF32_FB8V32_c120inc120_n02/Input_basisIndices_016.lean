import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_016 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 161, 158, 93, 30], #[109, 247, 243, 246, 161], #[109, 32, 158, 93, 30], #[109, 38, 119, 149, 40], #[109, 223, 149, 216, 37], #[109, 146, 223, 145, 143], #[109, 146, 29, 209, 143], #[109, 336, 334, 455, 338]]), (fun _ => #[#[109, 338, 281, 406, 454], #[109, 462, 322, 406, 454], #[109, 462, 322, 459, 454], #[109, 336, 338, 281, 333], #[109, 413, 409, 466, 26], #[109, 504, 495, 487, 505], #[109, 491, 502, 504, 495], #[109, 504, 246, 487, 466]]), (fun _ => #[#[109, 491, 504, 374, 487], #[109, 214, 207, 394, 212], #[109, 142, 159, 146, 152], #[109, 145, 152, 141, 143], #[109, 223, 145, 141, 143], #[109, 142, 33, 159, 146], #[109, 315, 219, 489, 395], #[109, 458, 417, 406, 459]]), (fun _ => #[#[109, 495, 458, 417, 406], #[109, 408, 462, 322, 406], #[109, 39, 42, 40, 281], #[109, 39, 120, 40, 281], #[109, 120, 40, 214, 37], #[109, 336, 120, 281, 333], #[109, 225, 150, 223, 141], #[109, 150, 223, 149, 141]])]

#print axioms array_basisIndices_group_016
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
