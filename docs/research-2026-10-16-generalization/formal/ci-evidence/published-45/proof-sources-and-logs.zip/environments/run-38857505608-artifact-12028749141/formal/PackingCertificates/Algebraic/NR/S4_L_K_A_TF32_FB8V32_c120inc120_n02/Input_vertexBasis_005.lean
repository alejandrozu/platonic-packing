import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_005 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[352, 351, 351, 353, 354, 324, 339, 355, 356, 357, 358, 359, 360, 361, 361, 362, 363, 364, 365, 366, 367, 368, 369, 368, 362, 370, 371, 372, 372, 373, 373, 374]), (fun _ => #[375, 376, 377, 378, 379, 380, 338, 381, 382, 383, 384, 385, 385, 386, 387, 344, 388, 389, 390, 136, 237, 143, 391, 392, 391, 393, 391, 394, 395, 396, 397, 398]), (fun _ => #[395, 399, 400, 401, 351, 402, 403, 367, 402, 367, 404, 405, 406, 407, 353, 408, 409, 374, 410, 374, 341, 331, 411, 341, 412, 413, 346, 414, 415, 416, 417, 418]), (fun _ => #[419, 420, 421, 418, 385, 422, 423, 424, 425, 426, 412, 427, 350, 428, 429, 430, 431, 432, 433, 386, 226, 434, 174, 174, 237, 173, 226, 386, 435, 436, 437, 392])]

#print axioms array_vertexBasis_group_005
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
