import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_000 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 587, 477, 555, 440], #[109, 551, 448, 451, 513], #[109, 452, 377, 376, 451], #[109, 551, 506, 451, 513], #[109, 599, 588, 587, 555], #[109, 599, 598, 555, 596], #[109, 254, 359, 378, 201], #[109, 549, 587, 555, 548]]), (fun _ => #[#[109, 547, 556, 552, 548], #[109, 573, 562, 574, 572], #[109, 551, 547, 557, 552], #[109, 562, 574, 572, 564], #[109, 569, 574, 571, 564], #[109, 551, 448, 595, 451], #[109, 578, 451, 584, 552], #[109, 588, 587, 555, 440]]), (fun _ => #[#[109, 326, 325, 328, 548], #[109, 325, 328, 547, 548], #[109, 328, 547, 378, 548], #[109, 391, 562, 574, 459], #[109, 567, 573, 566, 562], #[109, 567, 573, 566, 391], #[109, 376, 359, 379, 201], #[109, 376, 204, 379, 378]]), (fun _ => #[#[109, 376, 451, 569, 378], #[109, 381, 358, 563, 379], #[109, 381, 563, 376, 379], #[109, 563, 376, 569, 379], #[109, 379, 552, 378, 564], #[109, 377, 451, 552, 378], #[109, 569, 379, 378, 564], #[109, 560, 552, 582, 564]])]

#print axioms array_basisIndices_group_000
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
