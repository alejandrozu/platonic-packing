import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Sources
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Bases
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Vertices000
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Vertices001
import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Pair000_001

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem source_checked : certificate.sourceCheck = true := by
  apply sourceCheck_of_pieces
  · decide +kernel
  · intro i; fin_cases i
    · exact source_piece_0
    · exact source_piece_1

theorem placements_checked : certificate.placementCheck = true := by
  apply placementCheck_of_vertices
  intro i p; fin_cases i
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_0 p)).1
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_1 p)).1

theorem containment_checked : certificate.containmentCheck = true := by
  apply containmentCheck_of_vertices
  intro i p; fin_cases i
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_0 p)).2
  · exact (Bool.and_eq_true_iff.mp (vertices_piece_1 p)).2

theorem pairs_checked : certificate.pairsCheck = true := by
  apply pairsCheck_of_pairs
  intro i j hij; fin_cases i <;> fin_cases j <;> try (norm_num at hij)
  all_goals first
    | exact pair_0_1

theorem checked : certificate.check = true := by
  simp only [Certificate.check,source_checked,templates_checked,placements_checked,bases_checked,containment_checked,pairs_checked] <;> rfl

theorem valid : certificate.Valid := certificate.check_sound checked
theorem proper_orientation (i) : Matrix.det (fun a z => (certificate.rotation i a z : ℝ)) = 1 := certificate.proper_rotation checked i


#print axioms valid
#print axioms proper_orientation
#print axioms native_mu_binding
#print axioms native_mu_literal
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
