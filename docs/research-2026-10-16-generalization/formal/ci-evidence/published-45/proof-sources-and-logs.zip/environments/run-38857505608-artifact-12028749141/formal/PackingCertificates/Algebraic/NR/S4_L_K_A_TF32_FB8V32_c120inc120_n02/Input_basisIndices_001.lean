import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_001 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 560, 578, 574, 564], #[109, 579, 575, 516, 560], #[109, 560, 578, 584, 552], #[109, 557, 552, 548, 596], #[109, 546, 551, 547, 557], #[109, 557, 555, 548, 596], #[109, 546, 547, 556, 557], #[109, 559, 551, 595, 557]]), (fun _ => #[#[109, 556, 557, 552, 548], #[109, 598, 552, 548, 596], #[109, 595, 451, 552, 510], #[109, 451, 584, 552, 510], #[109, 551, 595, 451, 552], #[109, 598, 584, 589, 552], #[109, 598, 589, 582, 596], #[109, 595, 598, 589, 596]]), (fun _ => #[#[109, 559, 551, 448, 595], #[109, 583, 598, 584, 582], #[109, 587, 598, 582, 596], #[109, 587, 585, 582, 596], #[109, 587, 417, 585, 582], #[109, 587, 477, 374, 480], #[109, 491, 482, 587, 502], #[109, 586, 479, 587, 374]]), (fun _ => #[#[109, 203, 254, 204, 378], #[109, 375, 377, 376, 378], #[109, 375, 376, 204, 378], #[109, 546, 377, 547, 287], #[109, 325, 328, 547, 378], #[109, 202, 547, 378, 20], #[109, 360, 473, 328, 379], #[109, 326, 328, 477, 548]])]

#print axioms array_basisIndices_group_001
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
