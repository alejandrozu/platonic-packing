import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_009 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[604, 663, 664, 665, 660, 649, 645, 666, 667, 668, 569, 553, 669, 670, 553, 568, 614, 553, 670, 614, 614, 671, 610, 613, 672, 653, 673, 673, 674, 554, 675, 676]), (fun _ => #[677, 633, 678, 679, 680, 647, 654, 637, 681, 657, 631, 666, 637, 682, 677, 683])]

#print axioms array_vertexBasis_group_009
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
