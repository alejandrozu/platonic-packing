import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_020 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 489, 500, 494, 488], #[109, 498, 499, 489, 404], #[109, 495, 500, 505, 490], #[109, 492, 491, 495, 585], #[109, 491, 504, 495, 487], #[109, 318, 324, 500, 319], #[109, 318, 324, 40, 395], #[109, 318, 40, 395, 207]]), (fun _ => #[#[109, 40, 395, 281, 207], #[109, 399, 324, 500, 322], #[109, 225, 226, 223, 217], #[109, 216, 209, 214, 207], #[109, 216, 217, 209, 214], #[109, 226, 223, 217, 209], #[109, 324, 40, 395, 281], #[109, 322, 281, 406, 394]]), (fun _ => #[#[109, 399, 500, 406, 394], #[109, 395, 281, 207, 394], #[109, 408, 399, 322, 406], #[109, 399, 324, 322, 406], #[109, 497, 418, 500, 505], #[109, 500, 322, 319, 488], #[109, 500, 505, 490, 488], #[109, 486, 489, 487, 488]]), (fun _ => #[#[109, 87, 489, 209, 488], #[109, 497, 502, 495, 500], #[109, 318, 395, 207, 488], #[109, 219, 489, 209, 207], #[109, 96, 315, 219, 209], #[109, 96, 87, 315, 209], #[109, 315, 219, 489, 209], #[109, 96, 98, 87, 218]])]

#print axioms array_basisIndices_group_020
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
