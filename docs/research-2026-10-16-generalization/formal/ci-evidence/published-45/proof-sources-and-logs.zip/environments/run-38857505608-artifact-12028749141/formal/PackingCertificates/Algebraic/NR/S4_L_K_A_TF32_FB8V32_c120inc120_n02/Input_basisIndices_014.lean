import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_014 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 410, 242, 322, 300], #[109, 160, 161, 409, 26], #[109, 160, 157, 161, 26], #[109, 238, 157, 240, 241], #[109, 25, 157, 152, 26], #[109, 142, 159, 152, 93], #[109, 159, 157, 152, 93], #[109, 246, 161, 93, 30]]), (fun _ => #[#[109, 247, 160, 246, 93], #[109, 31, 33, 159, 93], #[109, 487, 409, 505, 93], #[109, 247, 504, 246, 409], #[109, 86, 247, 409, 93], #[109, 409, 505, 93, 488], #[109, 242, 338, 12, 333], #[109, 114, 119, 12, 333]]), (fun _ => #[#[109, 384, 299, 393, 300], #[109, 24, 186, 25, 299], #[109, 388, 331, 300, 333], #[109, 384, 388, 300, 333], #[109, 337, 389, 338, 333], #[109, 389, 384, 338, 464], #[109, 337, 242, 338, 333], #[109, 297, 384, 299, 200]]), (fun _ => #[#[109, 195, 299, 12, 200], #[109, 482, 504, 413, 417], #[109, 412, 410, 413, 417], #[109, 412, 410, 413, 300], #[109, 484, 415, 475, 413], #[109, 413, 299, 409, 300], #[109, 411, 247, 409, 466], #[109, 485, 504, 413, 409]])]

#print axioms array_basisIndices_group_014
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
