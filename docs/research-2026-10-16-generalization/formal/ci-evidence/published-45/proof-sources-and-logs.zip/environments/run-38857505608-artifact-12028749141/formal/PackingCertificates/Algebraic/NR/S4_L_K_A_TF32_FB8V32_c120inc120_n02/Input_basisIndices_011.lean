import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_011 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 85, 189, 163, 25], #[109, 154, 155, 149, 195], #[109, 40, 281, 12, 319], #[109, 16, 40, 12, 319], #[109, 322, 338, 281, 319], #[109, 322, 505, 319, 488], #[109, 40, 209, 319, 143], #[109, 324, 500, 322, 319]]), (fun _ => #[#[109, 119, 16, 120, 12], #[109, 38, 119, 16, 40], #[109, 38, 144, 16, 149], #[109, 120, 40, 12, 333], #[109, 16, 120, 40, 12], #[109, 114, 119, 195, 12], #[109, 119, 149, 195, 12], #[109, 25, 149, 195, 15]]), (fun _ => #[#[109, 119, 16, 149, 12], #[109, 119, 149, 120, 40], #[109, 148, 38, 223, 149], #[109, 149, 120, 40, 37], #[109, 223, 149, 141, 143], #[109, 144, 155, 149, 143], #[109, 149, 152, 141, 143], #[109, 89, 90, 93, 143]]), (fun _ => #[#[109, 152, 93, 143, 26], #[109, 15, 93, 143, 26], #[109, 418, 502, 462, 417], #[109, 418, 462, 417, 459], #[109, 416, 418, 417, 459], #[109, 410, 502, 417, 505], #[109, 501, 497, 418, 505], #[109, 418, 410, 322, 505]])]

#print axioms array_basisIndices_group_011
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
