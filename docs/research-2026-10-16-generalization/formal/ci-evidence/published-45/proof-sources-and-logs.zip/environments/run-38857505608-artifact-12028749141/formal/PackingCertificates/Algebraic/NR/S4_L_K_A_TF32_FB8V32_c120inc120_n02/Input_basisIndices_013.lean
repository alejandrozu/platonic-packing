import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_013 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 415, 416, 412, 390], #[109, 321, 409, 15, 319], #[109, 90, 321, 409, 93], #[109, 321, 409, 93, 488], #[109, 414, 321, 409, 505], #[109, 410, 321, 409, 319], #[109, 197, 25, 297, 255], #[109, 475, 302, 391, 413]]), (fun _ => #[#[109, 475, 302, 391, 393], #[109, 475, 258, 302, 256], #[109, 297, 413, 299, 393], #[109, 186, 297, 195, 299], #[109, 197, 163, 25, 255], #[109, 186, 197, 163, 25], #[109, 302, 297, 413, 393], #[109, 468, 484, 475, 302]]), (fun _ => #[#[109, 302, 299, 255, 26], #[109, 25, 157, 255, 26], #[109, 243, 374, 480, 466], #[109, 161, 409, 466, 26], #[109, 468, 484, 302, 466], #[109, 322, 338, 281, 406], #[109, 242, 322, 338, 12], #[109, 322, 338, 12, 319]]), (fun _ => #[#[109, 242, 384, 300, 333], #[109, 418, 410, 462, 322], #[109, 410, 322, 300, 459], #[109, 322, 338, 300, 459], #[109, 337, 389, 242, 338], #[109, 464, 300, 459, 454], #[109, 322, 338, 459, 454], #[109, 242, 384, 338, 300]])]

#print axioms array_basisIndices_group_013
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
