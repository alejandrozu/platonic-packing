import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_basisIndices_group_018 : Array (Unit → Array (Array (Fin 600))) := #[(fun _ => #[#[109, 281, 214, 207, 394], #[109, 42, 40, 281, 214], #[109, 42, 120, 40, 214], #[109, 217, 209, 214, 212], #[109, 318, 209, 207, 488], #[109, 504, 374, 480, 487], #[109, 373, 485, 479, 491], #[109, 243, 342, 246, 374]]), (fun _ => #[#[109, 374, 480, 487, 466], #[109, 315, 489, 29, 2], #[109, 315, 489, 316, 494], #[109, 87, 315, 489, 29], #[109, 149, 216, 40, 37], #[109, 216, 40, 214, 207], #[109, 223, 216, 214, 37], #[109, 40, 281, 214, 207]]), (fun _ => #[#[109, 222, 215, 150, 223], #[109, 215, 150, 41, 223], #[109, 418, 502, 462, 406], #[109, 363, 408, 462, 322], #[109, 497, 418, 399, 500], #[109, 497, 418, 502, 406], #[109, 418, 399, 500, 322], #[109, 497, 407, 495, 406]]), (fun _ => #[#[109, 497, 502, 495, 406], #[109, 216, 40, 209, 143], #[109, 226, 223, 209, 143], #[109, 210, 318, 209, 207], #[109, 489, 209, 207, 488], #[109, 88, 87, 89, 209], #[109, 88, 320, 87, 209], #[109, 224, 218, 226, 146]])]

#print axioms array_basisIndices_group_018
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
