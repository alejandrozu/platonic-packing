import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_000 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[0, 1, 2, 3, 4, 5, 4, 6, 0, 7, 8, 7, 9, 8, 10, 11, 12, 13, 14, 15, 16, 16, 17, 18, 19, 20, 21, 22, 23, 24, 24, 25]), (fun _ => #[26, 27, 28, 29, 30, 31, 32, 33, 32, 34, 34, 34, 10, 35, 8, 10, 36, 8, 37, 38, 39, 40, 39, 41, 10, 10, 10, 42, 43, 44, 42, 45]), (fun _ => #[46, 47, 48, 46, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75]), (fun _ => #[76, 2, 24, 77, 78, 77, 78, 79, 80, 81, 82, 83, 77, 35, 84, 82, 85, 86, 87, 88, 89, 88, 90, 91, 92, 93, 94, 90, 95, 96, 97, 98])]

#print axioms array_vertexBasis_group_000
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
