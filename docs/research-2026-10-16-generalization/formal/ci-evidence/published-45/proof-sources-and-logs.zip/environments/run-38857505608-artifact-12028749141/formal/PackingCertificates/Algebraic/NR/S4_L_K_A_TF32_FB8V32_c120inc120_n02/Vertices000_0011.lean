import PackingCertificates.Algebraic.NR.S4_L_K_A_TF32_FB8V32_c120inc120_n02.Data
import PackingCertificates.Algebraic.FragmentND

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Rational
open PackingCertificates.Algebraic.PackingND
open PackingCertificates.Algebraic.FragmentND

theorem vertices_0_range_11 : rangeCheck 352 32 (by decide)
    (fun p => certificate.placedCheck 0 p && certificate.vertexContainmentCheck 0 p) = true := by decide +kernel

#print axioms vertices_0_range_11
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
