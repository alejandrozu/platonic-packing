import PackingCertificates.Algebraic.PackingND
import PackingCertificates.Algebraic.RootSqrt
import PackingCertificates.Algebraic.CN.V32_piece_c120.Data
import PackingCertificates.Algebraic.CN.V32_container_c120inc120.Data
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option trace.profiler false
set_option trace.profiler.threshold 1000
namespace PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
open PackingCertificates.Algebraic.PackingND

noncomputable def array_vertexBasis_group_002 : Array (Unit → Array (Fin 684)) := #[(fun _ => #[176, 159, 159, 177, 145, 178, 179, 83, 77, 77, 180, 181, 145, 178, 103, 182, 143, 143, 183, 184, 158, 162, 185, 176, 160, 33, 46, 186, 187, 188, 51, 189]), (fun _ => #[190, 191, 192, 193, 194, 122, 195, 194, 194, 133, 196, 19, 197, 198, 133, 152, 152, 42, 43, 42, 199, 200, 201, 188, 155, 202, 203, 76, 204, 205, 68, 206]), (fun _ => #[68, 68, 207, 208, 207, 106, 209, 147, 147, 209, 43, 210, 211, 212, 211, 213, 214, 215, 92, 210, 90, 216, 74, 217, 218, 1, 219, 204, 220, 221, 221, 199]), (fun _ => #[152, 222, 223, 224, 211, 225, 226, 174, 174, 227, 228, 229, 199, 230, 37, 231, 187, 232, 233, 234, 235, 27, 97, 103, 173, 189, 236, 237, 237, 173, 201, 238])]

#print axioms array_vertexBasis_group_002
end PackingCertificates.Algebraic.Generated.ND.Records.Chunked.S4_L_K_A_TF32_FB8V32_c120inc120_n02
